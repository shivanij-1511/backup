// class A{
//     show()
//     {
//         console.log("A Class");        
//     }
// }
// class B{
//     show()
//     {
//         console.log("B Class");        
//     }
// }
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Xyz = /** @class */ (function () {
    function Xyz() {
    }
    return Xyz;
}());
// Classes can only extend a single class.
var C = /** @class */ (function (_super) {
    __extends(C, _super);
    function C() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.data = "Cybage Software PVT LTD";
        return _this;
    }
    //Method overloading is not supported
    C.prototype.show = function () {
        console.log(this.data);
    };
    // show(name:string)
    // {
    //         console.log(name);
    // }
    C.prototype.print = function () {
        console.log("Interface Example");
    };
    return C;
}(Xyz));
var obj = new C();
obj.print();
obj.show();
