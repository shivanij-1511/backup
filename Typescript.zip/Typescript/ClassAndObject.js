var Book = /** @class */ (function () {
    // Initialization Constructor
    // Multiple constructor implementations are not allowed.
    // constructor()
    // {
    // console.log("Default Constructor");
    // }
    function Book(bn, an, p) {
        console.log("Parametrized COnstructor");
        // Copy data from local to instance variable
        this.bookName = bn;
        this.authorName = an;
        this.price = p;
    }
    Book.prototype.bookDetails = function () {
        console.log(this.bookName, "\t", this.authorName, "\t", this.price);
    };
    return Book;
}());
// Object of the class
// If value is not passed then it looks for default constructor if its paremtrized its mandatory to pass values
var obj = new Book("C Programming", "ABC", 500); //Call goes to Constructor
obj.bookDetails(); //access method on object
// access variable(data members) on object
console.log(obj.bookName); //private can access within class only
console.log(obj.authorName); //public can be access anywhere
