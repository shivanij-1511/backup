var book1 = {
    id: 1,
    name: "Rich Dad, Poor Dad",
    author: "Robert",
    price: 400
};
var book2 = {
    id: 1,
    name: "Rich, Poor Dad",
    author: "Robert",
    price: 300
};
function bookInfo(book) {
    return book;
}
var result = bookInfo(book2);
console.log(result);
