var Employee = /** @class */ (function () {
    function Employee(id, name, desig, salary) {
        this.id = id;
        this.name = name;
        this.designation = desig;
        // this.salary = salary;
    }
    Employee.prototype.display = function () {
        console.log(this.id, "\t", this.name, "\t", this.designation, "\t", this.salary);
    };
    return Employee;
}());
var emp = new Employee(1, "Sumat Jain", "Frontend Devloper", 5000);
emp.display();
