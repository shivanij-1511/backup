class Book
{
    [x: string]: any;   //data members--Instance variable--access using this keyword--'this' represent current class
    private bookName:string
    authorName:string
    price:number

// Initialization Constructor
// Multiple constructor implementations are not allowed.
    // constructor()
    // {
    // console.log("Default Constructor");
    
    // }
    constructor(bn:string, an:string, p:number)  //bn, an & p are in local scope variable
    {
        console.log("Parametrized COnstructor");
        // Copy data from local to instance variable
        this.bookName=bn
        this.authorName=an
        this.price=p
    }

    bookDetails(){
        console.log(this.bookName, "\t", this.authorName, "\t", this.price);
        
    }
}
// Object of the class
// If value is not passed then it looks for default constructor if its paremtrized its mandatory to pass values

let obj = new Book("C Programming", "ABC", 500) //Call goes to Constructor
obj.bookDetails() //access method on object
// access variable(data members) on object
console.log(obj.bookName); //private can access within class only
console.log(obj.authorName); //public can be access anywhere




