// function show(data:string):string
// {
//     return "Sumat";
// }

// call function
// let result
// result = show("Cybage Softwares")
// console.log(result);

// result= show(23.45)
// console.log(result);

// ARROW FUNCTION
/*No function name/keyword
after para list introduce '=>'
assigned arrow function to variable
Remove {} if we have single statement no need of curly paranthese{}
Remove 'return' keyword if we have single return statement in function body */

// let func = (r:number):number =>  3.14*r*r


// function circleArea(r:number):number
// {
//     return 3.14*r*r;
// }

// let ans = func(5)
// console.log("Area of circle is : "+ ans);



//--------------OBJECTS---------------
// Static Object
/*
function function_name(para list)
{
    //statements
}
*/
//function definition
// function show(data:string):string
// {
//     return "Sonali";
// }
// //call Function
// let result
// result=show("Cybage")
// console.log(result);
 
// result=show(23.45)
// console.log(result);
 
//Arrow function--number--float/int/double
/*
no function keyword/name
after para list introduce '=>'
assigned arrow function to variable
remove {} if we have single statement in function body
remove 'return' keyword if we have single return statement in function body
*/
// let func=(r:number):number=>3.14*r*r
 
// function circleArea(r:number):number
// {
//     return 3.14*r*r
// }
// let ans=func(2.3)
// console.log("Circle Area is:"+ans);
 
 
//Objects
//Static Object
let emp1={
    id:1,
    name:"Kirti",
    designation:"Manager"
}
 
let emp2={
    // id:"Two",
    id:2,
    name:"Sonali",
    designation:"Sr. Technical Trainer",
    salary:176000
}
interface emp_type{
    id:number,
    name:string,
    designation:string,
    salary?:number//optional property  
    // email:string
}
 
let employee:Array<emp_type>=[emp1,emp2]
 
function employeeDetails(emp:emp_type[])
{
    console.log(emp);    
}
// employeeDetails("Cybage")
console.log("-----------------------------------------");
employeeDetails(emp1)// as salary property is missing
console.log("------------------------------------------");
employeeDetails(emp2)// as id is of the type string and expection in type number
console.log("----------------------------------");
employeeDetails(employee)
 
 