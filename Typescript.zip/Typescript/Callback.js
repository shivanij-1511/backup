function msg(info) {
    console.log(info);
}
function display(abc) {
    console.log("In Display Function!!");
    abc("Cybage Soft. Private Ltd."); //function as parameter
}
// display("Sumat Jain")
// display(23)
// display(false)
// display(null)
// ----------Function Callback-- One function as a aparameter to another function
// display(msg)
display(function (info) { return console.log(info); }); //made to arrow function
