/*
Inheritance :- Getting properties (Variables and Methods) of one object/class into another object/class
*/
class Employee //Must act as Parent class
{
    id: number;
    name: string;
    designation: string;
    protected salary: number; //access in same & derived classes
    constructor(id: number, name: string, designation: string) {
        this.id = id;
        this.name = name;
        this.designation = designation;
        
    }
    display() {
        console.log(this.id, "\t", this.name, "\t", this.designation, "\t", this.salary);
    }
}

//Child Class/Subclass/Derived Class
 class PartTimeEmployee extends Employee
 {
    no_of_hrs:number
    hrs_sal:number

    constructor(id:number, name:string, designation:string, no_of_hrs:number, hrs_sal:number )
    {
       super(id, name, designation, ) //call parent Constructor--default constructor 
       this.no_of_hrs=no_of_hrs
       this.hrs_sal=hrs_sal
    }

    calSal()
    {
        this.salary = this.no_of_hrs*this.hrs_sal
    }
 }



let emp = new PartTimeEmployee(1, "Sumat Jain", "Frontend Devloper", 30, 5000);
emp.calSal()
emp.display(); //Inheritance-- on child object we have invoked parent property