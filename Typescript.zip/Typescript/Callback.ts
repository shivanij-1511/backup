function msg(info:string):void{
    console.log(info);
    
}

function display(abc):void
{
    console.log("In Display Function!!");
    abc("Cybage Soft. Private Ltd.")  //function as parameter
}

// display("Sumat Jain")
// display(23)
// display(false)
// display(null)
// ----------Function Callback-- One function as a aparameter to another function
// display(msg)
display((info:string):void =>console.log(info))  //made to arrow function
    
