// Compile Typescript code {tsc fileName.ts} ---- JS File is created automatically ----- Run JS {node fileName.js}
var val;
val = "Sumat";
console.log(val);
val = 78.36;
val = false;
val = null;
val = undefined;
