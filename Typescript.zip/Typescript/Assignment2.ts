class Employee {
    id: number;
    name: string;
    designation: string;
    salary?: number;
    constructor(id: number, name: string, desig: string, salary: number) {
        this.id = id;
        this.name = name;
        this.designation = desig;
        this.salary = salary;
    }
    display() {
        console.log(this.id, "\t", this.name, "\t", this.designation, "\t", this.salary);
    }
}
 
let emp = new Employee(1, "Sumat Jain", "Frontend Devloper", 5000);
emp.display();