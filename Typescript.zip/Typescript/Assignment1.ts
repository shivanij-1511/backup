interface book_type  {
    id: number,
    name: string,
    author: string,
    price: number
}
 
let book1 = {
    id:1,
    name: "Rich Dad, Poor Dad",
    author: "Robert",
    price : 400
}
let book2 = {
    id:1,
    name: "Rich, Poor Dad",
    author: "Robert",
    price : 300
}
 
function bookInfo(book:book_type){
    return book
}
 
let result = bookInfo(book2)
console.log(result);