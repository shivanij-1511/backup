// function show(data:string):string
// {
//     return "Sumat";
// }
// call function
// let result
// result = show("Cybage Softwares")
// console.log(result);
// result= show(23.45)
// console.log(result);
// ARROW FUNCTION
/*No function name/keyword
after para list introduce '=>'
assigned arrow function to variable
Remove {} if we have single statement no need of curly paranthese{}
Remove 'return' keyword if we have single return statement in function body */
// let func = (r:number):number =>  3.14*r*r
// function circleArea(r:number):number
// {
//     return 3.14*r*r;
// }
// let ans = func(5)
// console.log("Area of circle is : "+ ans);
//--------------OBJECTS---------------
// Static Object
var emp1 = {
    id: 1,
    name: "Sumat",
    designation: "Software Engineer"
};
var emp2 = {
    id: "Two",
    name: "Sonali",
    designation: "Sr. Trainer",
    salary: 28500
};
function employeeDetails(emp) {
    console.log(emp);
}
// employeeDetails("Cybage")
console.log("------------");
employeeDetails(emp1);
console.log("------------");
employeeDetails(emp2);
