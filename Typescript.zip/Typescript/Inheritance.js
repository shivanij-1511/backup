var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
/*
Inheritance :- Getting properties (Variables and Methods) of one object/class into another object/class
*/
var Employee //Must act as Parent class
 = /** @class */ (function () {
    function Employee(id, name, designation) {
        this.id = id;
        this.name = name;
        this.designation = designation;
    }
    Employee.prototype.display = function () {
        console.log(this.id, "\t", this.name, "\t", this.designation, "\t", this.salary);
    };
    return Employee;
}());
//Child Class/Subclass/Derived Class
var PartTimeEmployee = /** @class */ (function (_super) {
    __extends(PartTimeEmployee, _super);
    function PartTimeEmployee(id, name, designation, no_of_hrs, hrs_sal) {
        var _this = _super.call(this, id, name, designation) || this; //call parent Constructor--default constructor 
        _this.no_of_hrs = no_of_hrs;
        _this.hrs_sal = hrs_sal;
        return _this;
    }
    PartTimeEmployee.prototype.calSal = function () {
        this.salary = this.no_of_hrs * this.hrs_sal;
    };
    return PartTimeEmployee;
}(Employee));
var emp = new PartTimeEmployee(1, "Sumat Jain", "Frontend Devloper", 30, 5000);
emp.calSal();
emp.display(); //Inheritance-- on child object we have invoked parent property
