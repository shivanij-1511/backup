let x = "Sumat"
console.log(x);
x = 78.95;
console.log(x);
x=false;
console.log(x);