const mongoose = require("mongoose");

const connectWithDB = () => {
  mongoose
    .connect(process.env.DB_URL, {})
    .then(console.log(`Database Connected`))
    .catch((err) => {
      console.log(`Connection failed`, err);
    });
};

module.exports = connectWithDB;
