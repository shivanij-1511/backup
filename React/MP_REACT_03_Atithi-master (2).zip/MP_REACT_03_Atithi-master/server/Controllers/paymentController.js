const dotenv = require("dotenv");
dotenv.config();
const stripe = require("stripe")(process.env.STRIPE_SECRET_KEY);
const { createBookings } = require("../Controllers/bookingController");

exports.createCheckoutSession = async (req, res) => {
  try {
    const { booking } = req.body;
    const lineItems = [
      {
        price_data: {
          currency: "inr",
          product_data: {
            name: "Booking", // Add a name for your product here
            metadata: {
              fullName: booking.name,
              checkInDate: booking.checkIn,
              checkOutDate: booking.checkOut,
            },
          },
          unit_amount: booking.price * 100,
        },
        quantity: 1,
      },
    ];

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      line_items: lineItems,
      mode: "payment",
      success_url: "http://localhost:3000/account/bookings",
      cancel_url: "http://localhost:3000/cancel",
      customer_email: booking.email,
      billing_address_collection: "required",
      shipping_address_collection: {
        allowed_countries: ["US"],
      },
    });

    res.json({ id: session.id });
  } catch (err) {
    console.log("Error", err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};
