const Booking = require("../Models/Booking");

// Books a place
exports.createBookings = async (req, res) => {
  try {
    const userData = req.user;
    const { place, checkIn, checkOut, numOfGuests, name, phone, price } =
      req.body;

    // Check for overlapping dates
    const existingBookings = await Booking.find({
      place,
      $or: [
        {
          checkIn: { $lt: checkOut },
          checkOut: { $gte: checkIn },
        },
        {
          checkIn: { $lte: checkIn },
          checkOut: { $gt: checkIn },
        },
      ],
    });

    if (existingBookings.length > 0) {
      return res.status(400).json({
        message: "Booking dates overlap with existing bookings.",
      });
    }

    // If no overlap, create the new booking
    const booking = await Booking.create({
      user: userData.id,
      place,
      checkIn,
      checkOut,
      numOfGuests,
      name,
      phone,
      price,
    });

    res.status(200).json({
      booking,
    });
  } catch (err) {
    res.status(500).json({
      message: "Internal server error",
      error: err,
    });
  }
};

//Bookings by Id
exports.getBookings = async (req, res) => {
  try {
    const userData = req.user;
    if (!userData) {
      return res
        .status(401)
        .json({ error: "You are not authorized to access this page!" });
    }

    const bookings = await Booking.find({ user: userData._id }).populate(
      "place"
    );
    res.status(200).json({ bookings, success: true });
  } catch (err) {
    console.log(err);
    res.status(500).json({ message: "Internal server error", error: err });
  }
};

// Get All Bookings
exports.getAllBookings = async (req, res) => {
  try {
    const bookings = await Booking.find().populate("place");
    res.status(200).json({ bookings, success: true });
  } catch (err) {
    console.log(err);
    res.status(500).json({ message: "Internal server error", error: err });
  }
};
