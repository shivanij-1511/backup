const Place = require("../Models/Place");

// Adds a place in the DB
exports.addPlace = async (req, res) => {
  try {
    const userData = req.user;
    const {
      title,
      address,
      photos,
      category,
      description,
      perks,
      extraInfo,
      maxGuests,
      price,
      isapproved,
    } = req.body;
    const place = await Place.create({
      owner: userData.id,
      title,
      address,
      category,
      photos: photos,
      description,
      perks,
      extraInfo,
      maxGuests,
      price,
      isapproved,
    });
    res.status(200).json({
      place,
    });
  } catch (err) {
    res.status(500).json({
      message: "Internal server error",
      error: err,
    });
  }
};

// Returns user specific places
exports.userPlaces = async (req, res) => {
  try {
    const userData = req.user;
    const id = userData.id;
    res.status(200).json(await Place.find({ owner: id }));
  } catch (err) {
    res.status(500).json({
      message: "Internal serever error",
    });
  }
};

// Updates a place
exports.updatePlace = async (req, res) => {
  try {
    const userData = req.user;
    const userId = userData.id;
    const {
      id,
      title,
      address,
      addedPhotos,
      description,
      perks,
      extraInfo,
      maxGuests,
      price,
    } = req.body;

    const place = await Place.findById(id);
    if (userId === place.owner.toString()) {
      place.set({
        title,
        address,
        photos: addedPhotos,
        description,
        perks,
        extraInfo,
        maxGuests,
        price,
      });
      await place.save();
      res.status(200).json({
        message: "place updated!",
      });
    }
  } catch (err) {
    res.status(500).json({
      message: "Internal server error",
      error: err,
    });
  }
};

// Returns all the places in DB
exports.getPlaces = async (req, res) => {
  try {
    const places = await Place.find();
    res.status(200).json({
      places,
    });
  } catch (err) {
    res.status(500).json({
      message: "Internal server error",
    });
  }
};

// Returns single place, based on passed place id
exports.singlePlace = async (req, res) => {
  try {
    const { id } = req.params;
    const place = await Place.findById(id);
    if (!place) {
      return res.status(400).json({
        message: "Place not found",
      });
    }
    res.status(200).json({
      place,
    });
  } catch (err) {
    res.status(500).json({
      message: "Internal serever error",
    });
  }
};

// Search Places in the DB
exports.searchPlaces = async (req, res) => {
  try {
    const searchword = req.params.key;

    if (searchword === "") return res.status(200).json(await Place.find());
    const searchMatches = await Place.find({
      $or: [
        { title: { $regex: searchword, $options: "i" } },
        { address: { $regex: searchword, $options: "i" } },
      ],
    });

    res.status(200).json(searchMatches);
  } catch (err) {
    console.log(err);
    res.status(500).json({
      message: "Internal serever error 1",
    });
  }
};

// delete places
exports.deletePlace = async (req, res) => {
  const { idTodelete } = req.body;

  try {
    // Delete the user with the given id and email
    await Place.deleteOne({ _id: idTodelete });

    // Fetch and return the updated list of users
    const updatedplaces = await Place.find();
    res.status(200).json({ places: updatedplaces });
  } catch (error) {
    res.status(500).json({ error: "Internal server error" });
  }
};

//Change Approve status
exports.approve = async (req, res) => {
  const { id } = req.params;

  try {
    // Find the place by ID and update isapproved to true
    const updatedPlace = await Place.findByIdAndUpdate(id, {
      isapproved: true,
    });

    if (!updatedPlace) {
      return res.status(404).json({ message: "Place not found" });
    }

    // Fetch and return the updated list of places
    const updatedPlaces = await Place.find();
    res.status(200).json({ places: updatedPlaces });
  } catch (error) {
    console.error("Error approving place:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};
