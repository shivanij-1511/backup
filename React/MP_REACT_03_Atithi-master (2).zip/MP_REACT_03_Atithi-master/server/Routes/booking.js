const express = require("express");
const router = express.Router();
const { isLoggedIn } = require("../Middleware/user");
const { createCheckoutSession } = require("../Controllers/paymentController");
const {
  createBookings,
  getAllBookings,
  getBookings,
} = require("../Controllers/bookingController");

// Protected routes (user must be logged in)
router.route("/").get(isLoggedIn, getBookings).post(isLoggedIn, createBookings);
router.route("/create-checkout-session").post(createCheckoutSession);
router.route("/allBookings").get(getAllBookings);
module.exports = router;
