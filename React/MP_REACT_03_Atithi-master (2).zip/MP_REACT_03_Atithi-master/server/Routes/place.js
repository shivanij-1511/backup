const express = require("express");
const router = express.Router();
const { isLoggedIn } = require("../Middleware/user");

const {
  addPlace,
  getPlaces,
  deletePlace,
  updatePlace,
  singlePlace,
  userPlaces,
  searchPlaces,
  approve,
} = require("../Controllers/placeController");

router.route("/").get(getPlaces);

// Protected routes (user must be logged in)
router.route("/add-places").post(isLoggedIn, addPlace);
router.route("/user-places").get(isLoggedIn, userPlaces);
router.route("/update-place").put(isLoggedIn, updatePlace);

// Not Protected routed but sequence should not be interfered with above routes
router.route("/:id").get(singlePlace);
router.route("/deleteplace").delete(deletePlace);
router.route("/approvePlace/:id").put(approve);
router.route("/search/:key").get(searchPlaces);

module.exports = router;
