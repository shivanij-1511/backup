const { register, login } = require("../Controllers/userController");
const User = require("../Models/User");

describe("User Registration and Login", () => {
  //Registration Test Cases
  // Mocking the necessary objects
  const mockRequest = (body) => ({ body });
  const mockResponse = () => {
    const res = {};
    res.status = jest.fn().mockReturnValue(res);
    res.json = jest.fn().mockReturnValue(res);
    return res;
  };

  // Mocking the User model functions
  const mockUserCreate = jest.spyOn(User, "create").mockResolvedValue({});
  const mockUserFindOne = jest.spyOn(User, "findOne").mockResolvedValue(null);

  afterEach(() => {
    jest.clearAllMocks();
  });

  it("should register a new user", async () => {
    const req = mockRequest({
      name: "John Doe",
      email: "john.doe@example.com",
      password: "Pass@123",
      role: false,
    });
    const res = mockResponse();

    await register(req, res);

    expect(mockUserFindOne).toHaveBeenCalledWith({
      email: "john.doe@example.com",
    });
    expect(mockUserCreate).toHaveBeenCalledWith({
      name: "John Doe",
      email: "john.doe@example.com",
      password: "Pass@123",
      role: false,
    });
    expect(res.status).toHaveBeenCalledWith(200); // Assuming you want to send a 200 status on success
    // You might want to add more expectations based on your actual implementation
  });

  it("should handle missing fields", async () => {
    const req = mockRequest({}); // Empty request body
    const res = mockResponse();

    await register(req, res);

    expect(res.status).toHaveBeenCalledWith(400);
    expect(res.json).toHaveBeenCalledWith({
      message: "Name, email, password and role are required",
    });
    expect(mockUserCreate).not.toHaveBeenCalled();
  });

  it("should handle already registered user", async () => {
    const req = mockRequest({
      name: "John Doe",
      email: "john.doe@example.com",
      password: "password123",
      role: "user",
    });
    const res = mockResponse();
    mockUserFindOne.mockResolvedValueOnce({ email: "john.doe@example.com" });

    await register(req, res);

    expect(res.status).toHaveBeenCalledWith(400);
    expect(res.json).toHaveBeenCalledWith({
      message: "User already registered!",
    });
    expect(mockUserCreate).not.toHaveBeenCalled();
  });
  //Login Test Cases
  describe("User Login", () => {
    const mockRequest = (body) => ({ body });
    const mockResponse = () => {
      const res = {};
      res.status = jest.fn().mockReturnValue(res);
      res.json = jest.fn().mockReturnValue(res);
      return res;
    };

    const mockUserFindOne = jest.spyOn(User, "findOne");
    const mockIsValidatedPassword = jest.fn();

    afterEach(() => {
      jest.clearAllMocks();
    });

    it("should login a user", async () => {
      const req = mockRequest({
        email: "rakesh@gmail.com",
        password: "Pass@123",
      });
      const res = mockResponse();
      const mockUser = {
        email: "rakesh@gmail.com",
        isValidatedPassword: mockIsValidatedPassword.mockResolvedValue(true),
      };
      mockUserFindOne.mockResolvedValueOnce(mockUser);

      await login(req, res);

      expect(mockUserFindOne).toHaveBeenCalledWith({
        email: "rakesh@gmail.com",
      });
      expect(mockIsValidatedPassword).toHaveBeenCalledWith("Pass@123");
      expect(res.status).toHaveBeenCalledWith(200);
    });

    it("should handle missing email or password", async () => {
      const req = mockRequest({});
      const res = mockResponse();

      await login(req, res);

      expect(res.status).toHaveBeenCalledWith(400);
      expect(res.json).toHaveBeenCalledWith({
        message: "Email and password are required!",
      });
      expect(mockUserFindOne).not.toHaveBeenCalled();
    });

    it("should handle non-existing user", async () => {
      const req = mockRequest({
        email: "nonexistent@example.com",
        password: "password12",
      });
      const res = mockResponse();
      mockUserFindOne.mockResolvedValueOnce(null);

      await login(req, res);

      expect(res.status).toHaveBeenCalledWith(400);
      expect(res.json).toHaveBeenCalledWith({
        message: "User does not exist!",
      });
      expect(mockIsValidatedPassword).not.toHaveBeenCalled();
    });
  });
});
