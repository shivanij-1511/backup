import {
  createContext,
  useContext,
  useEffect,
  useState,
  ReactNode,
} from "react";
import axios from "axios";

interface Place {
  _id: string;
  photos?: string[];
  address: string;
  title: string;
  price: number;
  category: string;
  owner: string;
  isapproved: boolean;
}

interface PlaceContextProps {
  // places: { [key: string]: Place };
  places: Place[];
  deletePlace?: any;
  ApprovePlace?: any;
}

const PlaceContext = createContext<PlaceContextProps | undefined>(undefined);

const API = "http://localhost:3001/places";

interface PlaceProviderProps {
  children: ReactNode;
  initialPlaces: Place[];
}

const PlaceProvider = ({ children, initialPlaces }: PlaceProviderProps) => {
  const [places, setPlaces] = useState<Place[]>(initialPlaces);

  const getPlaces = async (url: string) => {
    try {
      const res = await axios.get(url);
      const placesData = await res.data;
      setPlaces(placesData.places);
    } catch (error) {
      console.log(error);
    }
  };

  const deletePlace = async (id: string) => {
    try {
      await fetch(`http://localhost:3001/places/deleteplace`, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ idTodelete: id }),
      });

      // Update the state after deletion
      setPlaces((prevPlaces) => prevPlaces.filter((place) => place._id !== id));
    } catch (error) {
      console.error("Error deleting place:", error);
      // Handle error as needed
    }
  };

  const ApprovePlace = async (id: string) => {
    try {
      const response = await fetch(
        `http://localhost:3001/places/approvePlace/${id}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      if (response.ok) {
        // Assuming your API returns the updated list of places after approval
        const data = await response.json();
        setPlaces((prevPlaces) =>
          prevPlaces.filter((place) => place._id !== id)
        );
      } else {
        console.error("Failed to approve place");
      }
    } catch (error) {
      console.error("Error approving place:", error);
    }
  };

  useEffect(() => {
    getPlaces(API);
  }, []);

  return (
    <PlaceContext.Provider value={{ places, deletePlace, ApprovePlace }}>
      {children}
    </PlaceContext.Provider>
  );
};

const usePlaceContext = () => {
  const context = useContext(PlaceContext);
  if (!context) {
    throw new Error("usePlaceContext must be used within a PlaceProvider");
  }
  return context;
};

export { PlaceProvider, usePlaceContext };
