import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import { PlaceProvider } from "./Context/PlaceContext";

const root = ReactDOM.createRoot(
  document.getElementById("root") as HTMLElement
);
const initialplaces: any = [];
root.render(
  <React.StrictMode>
    <PlaceProvider initialPlaces={initialplaces}>
      <App />
    </PlaceProvider>
  </React.StrictMode>
);
