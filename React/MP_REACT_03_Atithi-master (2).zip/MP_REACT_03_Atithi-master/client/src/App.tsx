import { useState } from "react";
import { Slide, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import "./App.css";
import HomePage from "./Components/Home/HomePage";
import Login from "./Components/Login/Login";
import NotFoundPage from "./Pages/NotFoundPage";
import ProfilePage from "./Pages/ProfilePage";
import MyAccomodations from "./Pages/MyAccomodations";
import MyBookingsPage from "./Pages/MyBookingsPage";
import Registration from "./Components/Registration/Registration";
import EditProfile from "./Components/EditProfile/EditProfile";
import BookingPage from "./Pages/BookingPage";
import PlacePageForm from "./Components/AddPlace/PlacePageForm";
import PaymentFailed from "./Pages/PaymentFailed";
import IndexPage from "./Pages/IndexPage";
import AdminPage from "./Pages/Admin";
import CategoriesResults from "./Pages/CategoriesReasults";
import FAQPage from "./Pages/FAQPage";
import ContactUsPage from "./Pages/ContactUs";
function App() {
  const [isEditProfileOpen, setIsEditProfileOpen] = useState(true);
  const userData = JSON.parse(localStorage.getItem("userData")!);
  const isAdmin = userData?.user?.role;

  const handleCloseEditProfile = () => {
    setIsEditProfileOpen(false);
    window.location.href = "/account";
  };

  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Registration />} />
          <Route path="/account" element={<ProfilePage />} />
          <Route path="/account/places/new" element={<PlacePageForm />} />
          <Route path="/place/:id" element={<BookingPage />} />
          <Route path="/account/places" element={<MyAccomodations />} />
          <Route path="/account/bookings" element={<MyBookingsPage />} />
          <Route path="*" element={<NotFoundPage />} />
          <Route path="/cancel" element={<PaymentFailed />} />
          <Route path="/index" element={<IndexPage searchResults={[]} />} />
          <Route path="/category" element={<CategoriesResults />} />
          {isAdmin ? (
            <Route path="/admin" element={<AdminPage />} />
          ) : (
            <Route path="/admin" element={<Navigate to="/" />} />
          )}
          <Route path="/faq" element={<FAQPage />} />
          <Route path="/contact" element={<ContactUsPage />} />
          <Route
            path="/edit"
            element={
              <EditProfile
                isOpen={isEditProfileOpen}
                onClose={handleCloseEditProfile}
              />
            }
          />
        </Routes>
      </BrowserRouter>
      <ToastContainer autoClose={2000} transition={Slide} />
    </>
  );
}

export default App;
