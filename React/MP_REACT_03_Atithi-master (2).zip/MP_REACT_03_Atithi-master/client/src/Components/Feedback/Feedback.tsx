import React from "react";

const Feedback = () => {
  return (
    <div className="flex flex-col flex-wrap lg:h-90 lg:flex-row md:flex-row justify-center  h-75 py-6">
      <div className="flex flex-col mt-16 border-2 border-gray-500  mx-4 text-gray-700 bg-white shadow-lg bg-clip-border rounded-xl w-80">
        <div className="h-22 w-22 mx-auto -translate-y-16  overflow-hidden text-white shadow-lg bg-clip-border rounded-full bg-gray-400 shadow-gray-400 border-2 border-gray-500">
          <img
            src="https://th.bing.com/th?id=OIP.j8yd8dJ5215WbgQ0NsLzuAHaNK&w=187&h=333&c=8&rs=1&qlt=90&o=6&pid=3.1&rm=2"
            alt="cardimage"
            className="h-40 w-40"
          />
        </div>
        <div className="p-6 -mt-16 text-center">
          <h5 className="block  font-sans text-xl antialiased font-semibold leading-snug tracking-normal text-blue-gray-900">
            Soham Villa Palace
          </h5>
          <span className="block  font-sans text-xl antialiased font-semibold leading-snug tracking-normal text-blue-gray-900">
            {" "}
            India
          </span>
          <p className="block font-sans text-base antialiased font-light leading-relaxed text-inherit">
            It was a great stay! The check-in/out process was very easy and
            convenient! Aman is very responsive and helpful too!
          </p>
        </div>
      </div>
      <div className="flex flex-col mt-16 border-2 border-gray-500  mx-4 text-gray-700 bg-white shadow-lg bg-clip-border rounded-xl w-80">
        <div className="h-22 w-22 mx-auto -translate-y-16  overflow-hidden text-white shadow-lg bg-clip-border rounded-full bg-gray-400 shadow-gray-400 border-2 border-gray-500">
          <img
            src="https://cdn.pixabay.com/photo/2016/03/23/04/01/woman-1274056_640.jpg"
            alt="cardimage"
            className="h-40 w-40 "
          />
        </div>
        <div className="p-6 -mt-16 text-center">
          <h5 className="block  font-sans text-xl antialiased font-semibold leading-snug tracking-normal text-blue-gray-900">
            Borod Hill 7
          </h5>
          <span className="block  font-sans text-xl antialiased font-semibold leading-snug tracking-normal text-blue-gray-900">
            {" "}
            Goa, India
          </span>
          <p className="block font-sans text-base antialiased font-light leading-relaxed text-inherit">
            Ovwerall a good place to chill. However the bathroom was smelly and
            there is construction outside that makes too much noise.
          </p>
        </div>
      </div>
      <div className="flex flex-col mt-16 border-2 border-gray-500  mx-4 text-gray-700 bg-white shadow-lg bg-clip-border rounded-xl w-80">
        <div className="h-22 w-22 mx-auto -translate-y-16  overflow-hidden text-white shadow-lg bg-clip-border rounded-full  bg-gray-400 shadow-gray-400 border-2 border-gray-500">
          <img
            src="https://cdn.pixabay.com/photo/2017/03/27/13/28/man-2178721_1280.jpg"
            alt="cardimage"
            className="h-40 w-40"
          />
        </div>
        <div className="p-6 -mt-16 text-center">
          <h5 className="block  font-sans text-xl antialiased font-semibold leading-snug tracking-normal text-blue-gray-900">
            Wild Desert Resort
          </h5>
          <span className="block  font-sans text-xl antialiased font-semibold leading-snug tracking-normal text-blue-gray-900">
            {" "}
            Kerala,India
          </span>
          <p className="block font-sans text-base antialiased font-light leading-relaxed text-inherit">
            I had an amazing experience. It's such a beautiful location, very
            peaceful and private. The food was 10/10! The host was quick to
            respond and very helpful. Can't wait to come back!
          </p>
        </div>
      </div>
    </div>
  );
};

export default Feedback;
