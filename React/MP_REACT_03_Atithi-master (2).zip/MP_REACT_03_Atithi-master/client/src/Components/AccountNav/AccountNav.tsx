import React from "react";
import { FaRegUser } from "react-icons/fa";
import { TfiMenuAlt } from "react-icons/tfi";
import { IoHomeOutline } from "react-icons/io5";
import { Link } from "react-router-dom";

function AccountNav() {
  return (
    <nav className="mt-16 mb-8 flex w-full flex-col justify-center gap-6 p-8 md:flex-row md:p-0 ">
      <div className="flex flex-row shadow-xl justify-around mx-10 md:mx-0 gap-1 py-2 px-6 rounded-full bg-gray-800 text-white hover:scale-105 transform transition-transform duration-300  cursor-pointer">
        <Link className="flex flex-row  justify-between " to="/account">
          <FaRegUser className="mr-3 text-xl" />

          <span className=" cursor-pointer">My Profile</span>
        </Link>
      </div>
      {/*Same for this div class*/}
      <div className="flex justify-center shadow-xl mx-10 md:mx-0 gap-1 py-2 px-6 rounded-full bg-gray-800 text-white hover:scale-105 transform transition-transform duration-300 cursor-pointer">
        <Link className="flex flex-row  justify-between" to="/account/bookings">
          <TfiMenuAlt className="mr-3 text-xl" />
          My bookings
        </Link>
      </div>
      {/*Same for this div also. */}
      <div className="flex justify-center shadow-xl mx-10 md:mx-0 gap-1 py-2 px-6 rounded-full bg-gray-800 text-white hover:scale-105 transform transition-transform duration-300 cursor-pointer">
        <Link className="flex flex-row  justify-between" to="/account/places">
          <IoHomeOutline className="mr-3 text-xl" />
          My accomodations
        </Link>
      </div>
    </nav>
  );
}

export default AccountNav;
