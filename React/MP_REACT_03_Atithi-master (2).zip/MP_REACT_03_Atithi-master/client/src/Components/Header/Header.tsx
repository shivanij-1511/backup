import React from "react";
import { FaUser } from "react-icons/fa";
import Search from "../Search/Search";
import { Link } from "react-router-dom";

const Header: React.FC = () => {
  // Check if user exists in localStorage
  const userExists = localStorage.getItem("userData") !== null;

  return (
    <div className="w-full sticky top-0 z-10">
      <header className="bg-gray-800 text-white py-4 px-6 flex md:flex-nowrap items-center  w-full ">
        {/* Logo and Text */}
        <Link to="/" className="flex items-center gap-4 md:ml-32">
          <img
            src="https://res.cloudinary.com/daljqwxea/image/upload/v1709901906/Airbnb/Users/renmvpfdpynmkyrtenqi.png"
            alt="Website Logo"
            className="h-12 w-26 md:h-12 md:w-26"
          />
        </Link>

        {/* Search Bar */}
        <div className="flex-grow items-center md:mx-10">
          <Search />
        </div>

        {/* User Menu Icon */}
        {userExists ? (
          <div className="flex items-center md:ml-auto">
            <Link to={"/account"}>
              <FaUser className="text-5xl border-white border-2 rounded-full p-2" />
            </Link>
          </div>
        ) : (
          <>
            <div className="bg-gray-800 hover:bg-slate-600 py-2 px-4 text-md text-white rounded border border-slate focus:outline-none mt-2 focus:border-black mr-8">
              <Link to="/login" className="text-white">
                List Your Home
              </Link>
            </div>
            <div className="bg-gray-800 hover:bg-slate-600 py-2 px-4 text-md text-white rounded border border-slate focus:outline-none mt-2 focus:border-black">
              <Link to="/login" className="text-white">
                Login
              </Link>
            </div>
          </>
        )}
      </header>
    </div>
  );
};

export default Header;
