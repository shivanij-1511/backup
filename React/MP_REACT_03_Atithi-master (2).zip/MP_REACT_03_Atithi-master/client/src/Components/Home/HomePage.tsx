import React, { useState, useEffect } from "react";
import Header from "../Header/Header";
import Footer from "../Footer/Footer";
import CategoriesPage from "../../Pages/CategoriesPage";
import { usePlaceContext } from "../../Context/PlaceContext";
import { Link } from "react-router-dom";
import Feedback from "../Feedback/Feedback";

const HomePage = () => {
  const { places } = usePlaceContext();
  const approvedPlaces = places.filter((place) => place.isapproved);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const placesPerPage = 8;

  useEffect(() => {
    setTotalPages(Math.ceil(approvedPlaces.length / placesPerPage));
  }, [approvedPlaces]);

  const indexOfLastPlace = currentPage * placesPerPage;
  const indexOfFirstPlace = indexOfLastPlace - placesPerPage;
  const currentPlaces = approvedPlaces.slice(
    indexOfFirstPlace,
    indexOfLastPlace
  );

  const nextPage = () => {
    setCurrentPage((prevPage) => Math.min(prevPage + 1, totalPages));
  };

  const prevPage = () => {
    setCurrentPage((prevPage) => Math.max(prevPage - 1, 1));
  };

  return (
    <>
      <Header />
      <CategoriesPage />

      <div className="bg-white mt-10 py-6 sm:py-8 lg:py-12 align-center flex-center ">
        <h1
          className="mt-4 mb-3"
          style={{
            color: "black",
            fontFamily: "tangerine",
            fontSize: 50,
            fontStyle: "italic",
            textAlign: "center",
          }}
        >
          Discover the best
        </h1>
        <div className="mx-auto max-w-screen-2xl px-4 md:px-8  ">
          <div className="grid py-2 px-2  gap-9 sm:grid-cols-2  lg:grid-cols-3 xl:grid-cols-4">
            {currentPlaces.map((currentPlace) => (
              <div
                className="border-solid border-2 border-gray-400 rounded-t-lg shadow-lg mb-4"
                key={currentPlace._id}
              >
                <Link
                  to={`/place/${currentPlace._id}`}
                  key={currentPlace._id}
                  className="group relative block h-96 overflow-hidden rounded-t-lg bg-gray-100"
                >
                  {currentPlace.photos && currentPlace.photos.length > 0 && (
                    <img
                      src={currentPlace.photos[0]}
                      loading="lazy"
                      alt={currentPlace.title}
                      className="h-full w-full object-cover  transition duration-200 group-hover:scale-110"
                    />
                  )}
                </Link>
                <div className="flex border-black-500 justify-start text-left items-start flex-col shadow-xl gap-2 rounded-b-lg bg-gray-100 p-4">
                  <div className="text-left items-start">
                    <span className="font-bold text-black-800 transition duration-100 hover:text-gray-500 lg:text-lg">
                      {currentPlace.title}
                    </span>
                    <br />
                    <span className="text-sm text-green-700 ">
                      ₹ {currentPlace.price} per night
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      <div className="flex justify-center mt-4 mb-6">
        <button
          className={`mx-2 px-3 py-1 border-2 border-gray-500 shadow-xl text-bold text-3xl rounded-lg ${
            currentPage === 1
              ? "bg-gray-200 text-gray-700"
              : "bg-gray-800 text-white"
          }`}
          onClick={prevPage}
          disabled={currentPage === 1}
        >
          &larr;
        </button>
        <button
          className={`mx-2 px-3  text-3xl border-2 border-gray-500 shadow-xl font-bold py-1 rounded-lg ${
            currentPage === totalPages
              ? "bg-gray-200 text-gray-700"
              : "bg-gray-800 text-white"
          }`}
          onClick={nextPage}
          disabled={currentPage === totalPages}
        >
          &rarr;
        </button>
      </div>
      <hr className="h-px my-18 shadow-xl bg-gray-200 border-0 dark:bg-gray-800"></hr>
      <div className="mt-7">
        <h1
          className="mb-3"
          style={{
            color: "black",
            fontFamily: "tangerine",
            fontSize: 50,
            fontStyle: "italic",
            textAlign: "center",
          }}
        >
          Overheard from travelers
        </h1>
        <Feedback />
      </div>

      <Footer />
    </>
  );
};

export default HomePage;
