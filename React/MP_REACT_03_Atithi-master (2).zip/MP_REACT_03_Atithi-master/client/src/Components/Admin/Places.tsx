import React, { useState } from "react";
import { usePlaceContext } from "../../Context/PlaceContext";

const Places: React.FC = () => {
  const { places, deletePlace, ApprovePlace } = usePlaceContext();
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(10);

  const handleDeletePlace = async (id: string) => {
    try {
      await deletePlace(id);
    } catch (error) {
      console.error("Error deleting place:", error);
    }
  };

  const handleApprove = async (id: string) => {
    try {
      await ApprovePlace(id);
    } catch (error) {
      console.error("Error deleting place:", error);
    }
  };

  const handlePreviousPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handleNextPage = () => {
    const maxPage = Math.ceil(places.length / pageSize);
    if (currentPage < maxPage) {
      setCurrentPage(currentPage + 1);
    }
  };

  const startIndex = (currentPage - 1) * pageSize;
  const endIndex = startIndex + pageSize;
  const displayedPlaces = places.slice(startIndex, endIndex);

  let counter = startIndex + 1;

  return (
    <div className="p-4 border rounded-xl">
      <link
        rel="stylesheet"
        href="https://demos.creative-tim.com/notus-js/assets/styles/tailwind.css"
      />
      <link
        rel="stylesheet"
        href="https://demos.creative-tim.com/notus-js/assets/vendor/@fortawesome/fontawesome-free/css/all.min.css"
      />

      <section className="py-1 bg-blueGray-50">
        {/* <Dashboard /> */}
        <div className="w-full px-4 mx-auto mt-4 lg:mt-24">
          <h2 className="text-2xl px-2 font-bold mb-4">Properties</h2>
          <div className="relative flex flex-col min-w-0 break-words bg-white w-full mb-6 border-2 rounded-xl shadow-2xl">
            <div className="rounded-t mb-0 px-4 py-3 border-0">
              <div className="flex flex-wrap items-center">
                <div className="block w-full overflow-x-auto">
                  <table className="items-center text-center bg-transparent w-full border-collapse">
                    <thead>
                      <tr>
                        <th className="px-6 bg-blueGray-50 text-center text-blueGray-500 align-middle border border-solid border-blueGray-100 py-3 text-lg uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left">
                          SR.No
                        </th>
                        <th className="px-6 bg-blueGray-50 text-center text-blueGray-500 align-middle border border-solid border-blueGray-100 py-3 text-lg uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left">
                          Property Name
                        </th>
                        <th className="px-6 bg-blueGray-50 text-center text-blueGray-500 align-middle border border-solid border-blueGray-100 py-3 text-lg uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left">
                          Property Address
                        </th>
                        <th className="px-6 bg-blueGray-50 text-center text-blueGray-500 align-middle border border-solid border-blueGray-100 py-3 text-lg uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left">
                          Status
                        </th>
                        <th className="px-6 bg-blueGray-50 text-center text-blueGray-500 align-middle border border-solid border-blueGray-100 py-3 text-lg uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left">
                          Action
                        </th>
                      </tr>
                    </thead>

                    <tbody>
                      {displayedPlaces.map((place) => (
                        <tr key={place._id}>
                          <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-lg whitespace-nowrap p-4">
                            {counter++}
                          </td>
                          <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-lg whitespace-nowrap p-4">
                            {place.title}
                          </td>
                          <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-lg whitespace-nowrap p-4">
                            {place.address}
                          </td>
                          <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-lg whitespace-nowrap p-4">
                            {place.isapproved ? "Approved" : "Not Approved"}
                          </td>
                          <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-l whitespace-nowrap p-4">
                            <button
                              className={`bg-${
                                place.isapproved ? "gray-400" : "green-800"
                              } text-${
                                place.isapproved ? "white" : "black"
                              } text-xs font-bold uppercase px-3 py-1 rounded focus:outline-none mr-2 mb-1 ease-linear transition-all duration-150 border-2 border-gray-500`}
                              type="button"
                              disabled={place.isapproved}
                              onClick={() => handleApprove(place._id)}
                            >
                              Approve
                            </button>
                            <button
                              className="bg-red-500 text-white active:bg-red-400 text-xs font-bold uppercase px-3 py-1 rounded outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150  border-2 border-red-500"
                              type="button"
                              onClick={() => handleDeletePlace(place._id)}
                            >
                              delete
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>

          {/* Pagination Buttons */}
          <div className="flex justify-center mt-4">
            <button
              onClick={handlePreviousPage}
              disabled={currentPage === 1}
              className="bg-gray-800 text-white active:bg-slate-400 text-xs font-bold uppercase px-3 py-2 rounded-l outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150"
            >
              Previous
            </button>
            <button
              onClick={handleNextPage}
              className="bg-gray-800 text-white active:bg-slate-400 text-xs font-bold uppercase px-3 py-2 rounded-r outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150"
            >
              Next
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Places;
