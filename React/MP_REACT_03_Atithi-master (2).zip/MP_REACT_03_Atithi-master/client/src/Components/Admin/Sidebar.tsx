import Axios from "axios";
import React from "react";
import { MdOutlineLogout } from "react-icons/md";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

interface SidebarProps {
  onSelectTab: (tab: string) => void;
  className?: string; // Add className prop
}

const Sidebar: React.FC<SidebarProps> = ({ onSelectTab, className }) => {
  //Logout Function
  const navigate = useNavigate();
  const handleLogout = async () => {
    try {
      const response = await Axios.post("http://localhost:3001/user/logout");
      if (response.status === 200) {
        toast.success(response.data.message);
        localStorage.clear();
        navigate("/");
      } else {
        toast.error("Logout Failed");
      }
    } catch (error) {
      console.error("Error during logout:", error);
    }
  };

  return (
    <div className="bg-blueGray-50 text-gray-100  flex flex-col w-80 border-2 rounded-lg border-gray-500 mt-4 mb-4 mx-4">
      <div className="p-4 mt-4 text-black font-bold text-xl flex justify-center ">
        Admin Dashboard
      </div>
      <div className="w-32 h-32 flex items-center mx-auto justify-center bg-gray-200 rounded-full mb-4 hover:scale-105 transform transition-transform duration-300">
        <img
          src="https://res.cloudinary.com/daljqwxea/image/upload/v1709656247/Airbnb/Users/mqf3ssfqztg39qo3ethv.png"
          alt=""
          className="rounded-full"
        />
      </div>

      <nav className="flex flex-col text-xl mt-6 ">
        <span
          className="bg-gray-800 mx-4 text-bold py-4 cursor-pointer text-center my-4 flex justify-center shadow-xl rounded-lg border-2 hover:bg-gray-700"
          onClick={() => onSelectTab("bookings")}
        >
          Bookings
        </span>
        <span
          className="bg-gray-800 mx-4 my-4 text-bold py-4 cursor-pointer  flex justify-center shadow-xl rounded-lg border-2 hover:bg-gray-700"
          onClick={() => onSelectTab("places")}
        >
          Places
        </span>
        <span
          className="bg-gray-800 mx-4 my-4 text-bold py-4 cursor-pointer flex justify-center  shadow-xl rounded-lg border-2 hover:bg-gray-700"
          onClick={() => onSelectTab("users")}
        >
          Users
        </span>
      </nav>
      <span
        className="bg-gray-800 mx-4 text-bold py-4 cursor-pointer text-center my-4 flex justify-center shadow-xl rounded-lg border-2 hover:bg-gray-700"
        onClick={handleLogout}
      >
        <MdOutlineLogout className="text-2xl" />
        Log Out
      </span>
    </div>
  );
};

export default Sidebar;
