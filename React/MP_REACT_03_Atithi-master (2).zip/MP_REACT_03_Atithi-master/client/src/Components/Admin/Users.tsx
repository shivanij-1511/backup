import React, { useEffect, useState } from "react";

interface Users {
  _id: any;
  name: any;
  email: any;
  role: boolean;
}

const Users: React.FC = () => {
  const [users, setUsers] = useState<Users[]>([]);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(10);

  // Fetch and display users data here
  const fetchData = async () => {
    try {
      const response = await fetch("http://localhost:3001/user/allUsers");
      const data = await response.json();

      setUsers(data.users); // Assuming data is an array of booking objects
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    fetchData();
  }, [currentPage, pageSize]); // Update data when page size or current page changes

  const handlePreviousPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handleNextPage = () => {
    const maxPage = Math.ceil(users.length / pageSize);
    if (currentPage < maxPage) {
      setCurrentPage(currentPage + 1);
    }
  };

  const startIndex = (currentPage - 1) * pageSize;
  const endIndex = startIndex + pageSize;
  const displayedUsers = users.slice(startIndex, endIndex);

  let counter = startIndex + 1;

  return (
    <div className="p-4 border rounded-xl">
      <link
        rel="stylesheet"
        href="https://demos.creative-tim.com/notus-js/assets/styles/tailwind.css"
      />
      <link
        rel="stylesheet"
        href="https://demos.creative-tim.com/notus-js/assets/vendor/@fortawesome/fontawesome-free/css/all.min.css"
      />
      <section className="py-1 bg-blueGray-50">
        {/* <Dashboard /> */}
        <div className="w-full px-4 mx-auto mt-4 lg:mt-24">
          <h2 className="text-2xl px-2 font-bold mb-4">Users</h2>
          <div className="relative flex flex-col min-w-0 break-words bg-white w-full mb-6 border-2 rounded-xl shadow-2xl">
            <div className="rounded-t mb-0 px-4 py-3 border-0">
              <div className="flex flex-wrap items-center">
                <div className="block w-full overflow-x-auto">
                  <table className="items-center bg-transparent w-full border-collapse text-center">
                    <thead>
                      <tr>
                        <th className="px-6 bg-blueGray-50 text-blueGray-500 text-center align-middle border border-solid border-blueGray-100 py-3 text-lg uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left">
                          SR.No
                        </th>
                        <th className="px-6 bg-blueGray-50 text-blueGray-500 text-center align-middle border border-solid border-blueGray-100 py-3 text-lg uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left">
                          Name
                        </th>
                        <th className="px-6 bg-blueGray-50 text-blueGray-500 text-center align-middle border border-solid border-blueGray-100 py-3 text-lg uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left">
                          Emails
                        </th>
                        <th className="px-6 bg-blueGray-50 text-blueGray-500 text-center align-middle border border-solid border-blueGray-100 py-3 text-lg uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left">
                          Role
                        </th>
                      </tr>
                    </thead>

                    <tbody>
                      {displayedUsers.map((user) => (
                        <tr key={user._id}>
                          <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-lg whitespace-nowrap p-4">
                            {counter++}
                          </td>
                          <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-lg whitespace-nowrap p-4">
                            {user.name}
                          </td>
                          <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-lg whitespace-nowrap p-4">
                            {user.email}
                          </td>
                          <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-lg whitespace-nowrap p-4">
                            {user.role ? "Admin" : "User"}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
          {/* Pagination Buttons */}
          <div className="flex justify-center mt-4">
            <button
              onClick={handlePreviousPage}
              disabled={currentPage === 1}
              className="bg-gray-800 text-white active:bg-slate-400 text-xs font-bold uppercase px-3 py-2 rounded-l outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150"
            >
              Previous
            </button>
            <button
              onClick={handleNextPage}
              className="bg-gray-800 text-white active:bg-slate-400 text-xs font-bold uppercase px-3 py-2 rounded-r outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150"
            >
              Next
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Users;
