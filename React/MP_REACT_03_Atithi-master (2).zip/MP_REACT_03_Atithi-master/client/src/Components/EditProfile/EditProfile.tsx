import React, { useState } from "react";
import axios from "axios";
import { toast } from "react-toastify";

interface EditProfileProps {
  isOpen: boolean;
  onClose: () => void;
}

const userData: any = localStorage?.getItem("userData");
const data = JSON.parse(userData);
const email = data?.user?.email;

const EditProfile: React.FC<EditProfileProps> = ({ isOpen, onClose }) => {
  const [picture, setPicture] = useState<File | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleProfileImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    const file = e.target.files?.[0];
    if (file) {
      setPicture(file);
    }
  };

  const handleSave = async () => {
    try {
      if (!picture) {
        // If no picture is selected, just close the modal
        onClose();
        return;
      }

      const formData = new FormData();
      formData.append("picture", picture);
      formData.append("email", email);

      // Upload profile picture
      const pictureResponse = await axios.post(
        "http://localhost:3001/user/upload-picture",
        formData
      );

      if (pictureResponse.status === 200) {
        toast.success("Profile Picture Updated");
        onClose(); // Close the modal after updating the picture
      } else {
        toast.error("An Error Occured");
        setError("Error updating profile picture");
      }
    } catch (error) {
      setError("Error updating profile picture");
    }
  };

  const handleModalClose = (e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent the click event from propagating to the background
    onClose();
  };

  return (
    <div
      className={`${
        isOpen ? "block" : "hidden"
      } fixed inset-0 overflow-y-auto flex items-center justify-center`}
    >
      <div
        className="fixed inset-0 bg-gray-100 bg-opacity-75 z-10"
        onClick={handleModalClose}
      ></div>

      <div className="bg-white p-6  rounded-md border-solid border-2 border-gray-500  shadow-lg w-4/12 justify-center text-center z-20">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-semibold">Edit Profile Picture</h2>
          <button
            className="text-gray-500 hover:text-gray-700"
            onClick={onClose}
          >
            <svg
              className="w-6 h-6"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M6 18L18 6M6 6l12 12"
              ></path>
            </svg>
          </button>
        </div>

        {/* Profile Image Upload */}
        <div className="mb-4">
          <label className="block text-gray-700 font-bold mb-2 text-xl">
            Choose Image
          </label>
          <input
            type="file"
            accept="image/*"
            onChange={handleProfileImageChange}
            className="border rounded p-2 w-2/4"
          />
          {picture && (
            <div className="rounded-full overflow-hidden h-32 w-32 mb-2">
              <img
                src={URL.createObjectURL(picture)}
                alt="Profile"
                className="w-full h-full object-cover"
              />
            </div>
          )}
        </div>
        <button
          className="bg-gray-800 text-white p-2 text-xl mx-auto rounded-md hover:bg-slate-500m cursor-pointer w-1/4"
          onClick={handleSave}
        >
          Save
        </button>

        {/* Display error message if any */}
        {error && <p className="text-red-500 mt-2">{error}</p>}
      </div>
    </div>
  );
};

export default EditProfile;
