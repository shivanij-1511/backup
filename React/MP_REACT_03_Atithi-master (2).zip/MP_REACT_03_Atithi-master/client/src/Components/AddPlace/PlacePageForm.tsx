import React, { ChangeEvent, useState } from "react";
import {
  FaWifi,
  FaCar,
  FaSwimmingPool,
  FaDumbbell,
  FaUtensils,
  FaSnowflake,
  FaPaw,
  FaDoorOpen,
  FaUpload,
} from "react-icons/fa";
import Header from "../Header/Header";
import Footer from "../Footer/Footer";
import { toast } from "react-toastify";
import { useNavigate } from "react-router-dom";

interface FormData {
  category: string;
  title: string;
  address: string;
  photos: string[];
  description: string;
  perks: {
    [key: string]: boolean;
  };
  extraInfo: string;
  maxGuests: string;
  price: number | string;
}

const userData: any = localStorage?.getItem("userData");
const user = JSON.parse(userData);
const token = user.token;

function PlacePageForm() {
  const [formData, setFormData] = useState<FormData>({
    title: "",
    address: "",
    photos: [],
    description: "",
    perks: {
      WiFi: false,
      "Free Parking Spot": false,
      Pool: false,
      Gym: false,
      Kitchen: false,
      AC: false,
      Pets: false,
      "Private Entrance": false,
    },
    extraInfo: "",
    maxGuests: "1",
    price: 0,
    category: "Other",
  });
  const [errors, setErrors] = useState<Partial<FormData>>({});
  const navigate = useNavigate();

  const handleChange = (
    e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ): void => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
    setErrors({ ...errors, [e.target.name]: "" });
  };

  const handleCheckboxChange = (e: ChangeEvent<HTMLInputElement>): void => {
    const { name, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      perks: {
        ...prev.perks,
        [name]: checked,
      },
    }));
  };

  const getSelectedPerks = (perks: { [key: string]: boolean }): string[] => {
    return Object.entries(perks)
      .filter(([perk, selected]) => selected)
      .map(([perk]) => perk);
  };

  const uploadPhotos = async (
    e: ChangeEvent<HTMLInputElement>
  ): Promise<void> => {
    const files = e.target.files;
    if (files) {
      const formData = new FormData();

      // Append each file to the FormData object with the name "photos"
      Array.from(files).forEach((file, index) => {
        formData.append("photos", file);
      });

      try {
        const response = await fetch("http://localhost:3001/upload", {
          method: "POST",
          body: formData,
        });

        if (response.ok) {
          const uploadedPhotos = await response.json();

          setFormData((prev) => ({
            ...prev,
            photos: [...uploadedPhotos],
          }));
        } else {
          console.error("Error uploading photos:", response.statusText);
        }
      } catch (error) {
        console.error("Error uploading photos:", error);
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const validationErrors = validateFormData(formData);
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }
    const formattedData = {
      ...formData,
      perks: getSelectedPerks(formData.perks),
      isapproved: false,
    };

    try {
      const response = await fetch("http://localhost:3001/places/add-places", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(formattedData),
      });
      if (response.ok) {
        // Handle success
        toast.success("Property Details submitted successfully");
        navigate("/account/places");
      } else {
        // Handle error
        toast.error("Failed to submit your property details");
      }
    } catch (error) {
      console.error("Error:", error);
    }
  };

  const validateFormData = (data: FormData): Partial<FormData> => {
    let errors: Partial<FormData> = {};

    // Validate required fields
    if (!data.title) {
      errors.title = "Title is required.";
    }
    if (!data.address) {
      errors.address = "Address is required.";
    }
    if (!data.description) {
      errors.description = "Description is required.";
    }
    if (!data.extraInfo) {
      errors.extraInfo = "Terms and Conditions are required.";
    }
    if (!data.maxGuests) {
      errors.maxGuests = "Maximum number of guests is required.";
    }
    if (!data.price) {
      errors.price = "Price per night is required.";
    }

    return errors;
  };

  return (
    <>
      <Header />
      <div className="main-div border rounded mb-7 mt-7">
        <div className="container mx-auto px-4 py-8  bg-gray-100">
          <form onSubmit={handleSubmit} className="max-w mx-auto">
            <h2 className=" mb-4 text-center font-bold text-3xl text-black py-2 rounded">
              Add Your Property
            </h2>
            <div className="mb-4">
              <label
                htmlFor="title"
                className="block font-semibold mb-1 text-lg"
              >
                Title
              </label>
              <input
                type="text"
                id="title"
                name="title"
                value={formData.title}
                onChange={handleChange}
                className={`w-full p-2 border rounded ${
                  errors.title ? "border-red-500" : ""
                }`}
                required
              />
              {errors.title && (
                <p className="text-red-500 text-sm mt-1">{errors.title}</p>
              )}
            </div>

            <div className="mb-4">
              <label
                htmlFor="address"
                className="block text-lg font-semibold mb-1"
              >
                Address
              </label>
              <input
                type="text"
                id="address"
                name="address"
                value={formData.address}
                onChange={handleChange}
                className={`w-full p-2 border rounded ${
                  errors.address ? "border-red-500" : ""
                }`}
                required
              />
              {errors.address && (
                <p className="text-red-500 text-sm mt-1">{errors.address}</p>
              )}
            </div>

            <div className="mb-4">
              <label
                htmlFor="photos"
                className="block text-lg font-semibold mb-1"
              >
                Photos
                <span className="text-red-500"> minimum 5 photos required</span>
              </label>
              <div className="flex flex-col items-start">
                <div className="flex flex-wrap">
                  {formData.photos.map((photo, index) => (
                    <img
                      key={index}
                      src={photo}
                      alt={` ${index + 1}`}
                      className="w-32 h-32 object-cover mr-2 mb-2"
                    />
                  ))}
                </div>
                <input
                  type="file"
                  id="photos"
                  accept="image/*"
                  multiple
                  onChange={uploadPhotos}
                  className="hidden"
                />
                <label
                  htmlFor="photos"
                  className={`my-3 px-6 py-3 flex rounded-full bg-black text-xl font-semibold text-white ${
                    errors.photos ? "border-red-500" : ""
                  }`}
                >
                  <FaUpload className="mr-2" />
                  Upload Photo
                </label>
                {errors.photos && (
                  <p className="text-red-500 text-sm mt-1">{errors.photos}</p>
                )}
              </div>
            </div>

            <div className="mb-4">
              <label
                htmlFor="description"
                className="block  text-lg font-semibold mb-1"
              >
                Description
              </label>
              <textarea
                id="description"
                name="description"
                value={formData.description}
                onChange={handleChange}
                className={`w-full p-2 border rounded ${
                  errors.description ? "border-red-500" : ""
                }`}
                rows={4}
                required
              />
              {errors.description && (
                <p className="text-red-500 text-sm mt-1">
                  {errors.description}
                </p>
              )}
            </div>

            <label
              htmlFor="perks"
              className="block  text-lg font-semibold mb-1"
            >
              Perks
            </label>
            <div className="mb-4 grid grid-cols-2 gap-4 ">
              {Object.entries(formData.perks).map(([perk, checked]) => (
                <div
                  key={perk}
                  className="p-4 border  bg-white rounded-md flex items-center"
                >
                  <input
                    type="checkbox"
                    id={perk}
                    name={perk}
                    checked={checked}
                    onChange={handleCheckboxChange}
                    className="mr-2 "
                  />
                  <label htmlFor={perk} className="flex  items-center">
                    {perk === "WiFi" && <FaWifi className="mr-1" />}
                    {perk === "Free Parking Spot" && <FaCar className="mr-1" />}
                    {perk === "Pool" && <FaSwimmingPool className="mr-1" />}
                    {perk === "Gym" && <FaDumbbell className="mr-1" />}
                    {perk === "Kitchen" && <FaUtensils className="mr-1" />}
                    {perk === "AC" && <FaSnowflake className="mr-1" />}
                    {perk === "Pets" && <FaPaw className="mr-1" />}
                    {perk === "Private Entrance" && (
                      <FaDoorOpen className="mr-1" />
                    )}
                    {perk}
                  </label>
                </div>
              ))}
            </div>

            <div className="mb-4">
              <label
                htmlFor="extraInfo"
                className="block text-lg font-semibold mb-1"
              >
                Terms and Conditions
              </label>
              <textarea
                id="extraInfo"
                name="extraInfo"
                value={formData.extraInfo}
                onChange={handleChange}
                className={`w-full p-2 border rounded ${
                  errors.extraInfo ? "border-red-500" : ""
                }`}
                rows={4}
                required
              />
              {errors.extraInfo && (
                <p className="text-red-500 text-sm mt-1">{errors.extraInfo}</p>
              )}
            </div>

            <div className="grid grid-cols-2 gap-4 mb-4">
              <div>
                <label
                  htmlFor="maxGuests"
                  className="block text-lg  font-semibold mb-1"
                >
                  Maximum number of guests
                </label>
                <input
                  type="number"
                  id="maxGuests"
                  name="maxGuests"
                  value={formData.maxGuests}
                  onChange={handleChange}
                  className={`w-full p-2 border rounded ${
                    errors.maxGuests ? "border-red-500" : ""
                  }`}
                  required
                />
                {errors.maxGuests && (
                  <p className="text-red-500 text-sm mt-1">
                    {errors.maxGuests}
                  </p>
                )}
              </div>
              {/* Category field with radio buttons */}
              <div className="mb-4">
                <label
                  htmlFor="category"
                  className="block font-semibold mb-1 text-lg"
                >
                  Category
                </label>
                <div>
                  {[
                    "Palace",
                    "Hut",
                    "Beach",
                    "Villa",
                    "Desert",
                    "Mansion",
                    "Camp",
                    "Other",
                  ].map((category) => (
                    <div key={category} className="inline-block mr-4">
                      <input
                        type="radio"
                        id={category}
                        name="category"
                        value={category}
                        checked={formData.category === category}
                        onChange={handleChange}
                        className="mr-2"
                      />
                      <label htmlFor={category}>{category}</label>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <label
                  htmlFor="pricePerNight"
                  className="block text-lg  font-semibold mb-1"
                >
                  Price per night
                </label>
                <input
                  type="number"
                  id="price"
                  name="price"
                  value={formData.price}
                  onChange={handleChange}
                  className={`w-full p-2 border rounded ${
                    errors.price ? "border-red-500" : ""
                  }`}
                  required
                />
                {errors.price && (
                  <p className="text-red-500 text-sm mt-1">{errors.price}</p>
                )}
              </div>
            </div>

            <button
              type="submit"
              onClick={handleSubmit}
              className="mx-auto my-4 flex rounded-full bg-black py-3 px-20 text-xl font-semibold text-white"
            >
              Save
            </button>
          </form>
        </div>
      </div>
      <Footer />
    </>
  );
}

export default PlacePageForm;
