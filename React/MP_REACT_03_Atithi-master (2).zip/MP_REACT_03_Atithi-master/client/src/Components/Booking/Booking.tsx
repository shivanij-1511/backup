import { loadStripe } from "@stripe/stripe-js";
import axios from "axios";
import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { toast } from "react-toastify";

interface Place {
  _id: string;
  photos: string[];
  description: string;
  address: string;
  title: string;
  extraInfo: string;
  perks: any[];
  price: number;
}
const userData: any = localStorage?.getItem("userData");
const user = JSON.parse(userData);
const apiKey = process.env.REACT_APP_API_KEY;

const Booking: React.FC = () => {
  const { id } = useParams();
  const [place, setPlace] = useState<Place | null>(null);
  const [totalPrice, setTotalPrice] = useState<number | null>(0);
  const [checkIn, setCheckIn] = useState("");
  const [checkOut, setCheckOut] = useState("");
  const [numOfGuests, setNumOfGuests] = useState("");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [errors, setErrors] = useState({
    checkIn: "",
    checkOut: "",
    numOfGuests: "",
    name: "",
    phone: "",
  });
  let savesucess = false;
  const navigate = useNavigate();
  useEffect(() => {
    const fetchPlaceData = async () => {
      if (!id) {
        return;
      }

      try {
        const response = await axios.get(`http://localhost:3001/places/${id}`);
        setPlace(response.data.place);
      } catch (error) {
        console.error("Error fetching place details:", error);
      }
    };

    fetchPlaceData();
  }, [id]);

  const handleFullName = (value: string) => {
    setName(value);
    if (!value.trim()) {
      setErrors({
        ...errors,
        name: "Please enter your full name",
      });
    } else {
      setErrors({
        ...errors,
        name: "",
      });
    }
  };

  const handlePhoneNumber = (value: string) => {
    setPhone(value);

    // Regular expression pattern for Indian mobile numbers
    const indianPhoneNumberRegex = /^((\+91)|(0)|())?[6-9]\d{9}$/;

    if (!indianPhoneNumberRegex.test(value)) {
      setErrors({
        ...errors,
        phone: "Please enter a valid mobile number",
      });
    } else {
      setErrors({
        ...errors,
        phone: "",
      });
    }
  };

  const handleNumOfGuests = (value: string) => {
    setNumOfGuests(value);
    if (!value.trim()) {
      setErrors({
        ...errors,
        numOfGuests: "Please enter the number of guests",
      });
    } else {
      setErrors({
        ...errors,
        numOfGuests: "",
      });
    }
  };

  const handleCheckIn = (value: string) => {
    const selectedCheckInDate = new Date(value);
    const today = new Date();

    if (selectedCheckInDate < today) {
      setErrors({
        ...errors,
        checkIn: "Check-in date should not be in the past",
      });
      setCheckIn("");
      setTotalPrice(0);
    } else {
      setErrors({
        ...errors,
        checkIn: "",
      });
      setCheckIn(value);
      if (checkOut) {
        updateTotalPrice(value, checkOut, place?.price);
      }
    }
  };

  const handleCheckOut = (value: string) => {
    setCheckOut(value);

    const selectedCheckOutDate = new Date(value);
    const selectedCheckInDate = new Date(checkIn);

    if (selectedCheckOutDate <= selectedCheckInDate) {
      setErrors({
        ...errors,
        checkOut: "Check-out date should be after check-in date",
      });
      setTotalPrice(0);
    } else {
      setErrors({
        ...errors,
        checkOut: "",
      });
      updateTotalPrice(checkIn, value, place?.price);
    }
  };

  const updateTotalPrice = (
    checkInDate: string,
    checkOutDate: string,
    price: number | undefined
  ) => {
    const startDate = new Date(checkInDate);
    const endDate = new Date(checkOutDate);

    const timeDiff = Math.abs(endDate.getTime() - startDate.getTime());
    const numOfDays = Math.ceil(timeDiff / (1000 * 60 * 60 * 24));

    const total = price ? price * numOfDays : null;
    setTotalPrice(total);
  };

  //save data
  const handleSave = async () => {
    const price = totalPrice;
    const booking = {
      user: user.user._id,
      place,
      checkIn,
      checkOut,
      name,
      phone,
      price: price,
    };

    const token = user.token;
    const headers = {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    };
    try {
      const response = await fetch("http://localhost:3001/bookings/", {
        method: "POST",
        headers: headers,
        body: JSON.stringify(booking),
      });
      if (response.status === 400) {
        toast.error("Select Other Date");
        savesucess = false;
      } else {
        savesucess = true;
      }
    } catch (error) {
      console.error("Error during booking process:", error);
    }
  };

  const handleBookNow = async () => {
    // Check User is logged In
    const userExists = localStorage.getItem("userData") !== null;
    if (!userExists) {
      navigate("/login");
      return;
    }
    await handleSave();
    if (savesucess === true) {
      try {
        const token = user.token;

        if (!checkIn || !checkOut || !numOfGuests || !name || !phone) {
          setErrors({
            checkIn: "Please select checkin date",
            checkOut: "Please select checkout date",
            numOfGuests: "Please fill no of guests",
            name: "Please fill full name",
            phone: "Please fill phone number",
          });
          return;
        }

        const price = totalPrice;
        const booking = {
          place,
          checkIn,
          checkOut,
          numOfGuests,
          name,
          phone,
          price,
        };

        //Payment logic
        const stripe = await loadStripe(apiKey!);
        const body = {
          booking: booking,
        };
        const headers = {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        };

        const response = await fetch(
          "http://localhost:3001/bookings/create-checkout-session",
          {
            method: "POST",
            headers: headers,
            body: JSON.stringify(body),
          }
        );
        const session = await response.json();
        const result = await stripe?.redirectToCheckout({
          sessionId: session.id,
        });
        if (result) {
          toast.success("Payment Successful");
        } else {
          toast.error("Payment Failed");
        }
      } catch (error) {
        console.error("Error during booking process:", error);
      }
    }
  };

  return (
    <div className="max-w-md mx-auto p-6 bg-white rounded-md shadow-md ">
      <div className="text-xl font-semibold mb-4">
        Price: Rs <span>{place?.price}</span> per night
      </div>

      <div className="mb-4">
        <label
          htmlFor="checkIn"
          className="block text-sm font-medium text-gray-600"
        >
          Check-in Date
        </label>
        <input
          type="date"
          id="checkIn"
          className={`mt-1 p-2 w-full border rounded-md ${
            errors.checkIn && "border-red-500"
          }`}
          value={checkIn}
          onChange={(e) => handleCheckIn(e.target.value)}
          min={new Date().toISOString().split("T")[0]}
        />
        {errors.checkIn && (
          <p className="text-red-500 text-sm mt-1">{errors.checkIn}</p>
        )}
      </div>

      <div className="mb-4">
        <label
          htmlFor="checkOut"
          className="block text-sm font-medium text-gray-600"
        >
          Check-out Date
        </label>
        <input
          type="date"
          id="checkOut"
          className={`mt-1 p-2 w-full border rounded-md ${
            errors.checkOut && "border-red-500"
          }`}
          value={checkOut}
          onChange={(e) => handleCheckOut(e.target.value)}
        />
        {errors.checkOut && (
          <p className="text-red-500 text-sm mt-1">{errors.checkOut}</p>
        )}
      </div>

      <div className="mb-4">
        <label
          htmlFor="numOfGuests"
          className="block text-sm font-medium text-gray-600"
        >
          Number of Guests
        </label>
        <input
          type="number"
          id="numOfGuests"
          className={`mt-1 p-2 w-full border rounded-md ${
            errors.numOfGuests && "border-red-500"
          }`}
          value={numOfGuests}
          onChange={(e) => handleNumOfGuests(e.target.value)}
        />
        {errors.numOfGuests && (
          <p className="text-red-500 text-sm mt-1">{errors.numOfGuests}</p>
        )}
      </div>

      <div className="mb-4">
        <label
          htmlFor="name"
          className="block text-sm font-medium text-gray-600"
        >
          Full Name
        </label>
        <input
          type="text"
          id="name"
          className={`mt-1 p-2 w-full border rounded-md ${
            errors.name && "border-red-500"
          }`}
          value={name}
          onChange={(e) => handleFullName(e.target.value)}
        />
        {errors.name && (
          <p className="text-red-500 text-sm mt-1">{errors.name}</p>
        )}
      </div>

      <div className="mb-4">
        <label
          htmlFor="phone"
          className="block text-sm font-medium text-gray-600"
        >
          Phone Number
        </label>
        <input
          type="tel"
          id="phone"
          maxLength={10}
          className={`mt-1 p-2 w-full border rounded-md ${
            errors.phone && "border-red-500"
          }`}
          value={phone}
          onChange={(e) => handlePhoneNumber(e.target.value)}
        />
        {errors.phone && (
          <p className="text-red-500 text-sm mt-1">{errors.phone}</p>
        )}
      </div>

      <div className="flex">
        {totalPrice !== null && (
          <div className="text-xl font-semibold">
            Total Price: Rs <span>{totalPrice}</span>
          </div>
        )}
        <button
          type="button"
          className="ml-auto text-white py-2 px-4 rounded-md hover:bg-blue-600 bg-gray-800 hover:bg-slate-600 text-md text-white rounded border border-slate focus:outline-none mt-2 focus:border-black"
          onClick={handleBookNow}
        >
          Book Now
        </button>
      </div>
    </div>
  );
};
export default Booking;
