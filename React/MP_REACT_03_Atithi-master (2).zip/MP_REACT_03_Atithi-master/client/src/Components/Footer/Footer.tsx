import React from "react";
import { Link } from "react-router-dom";

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-800 text-gray-300 bottom-0 left-0 w-full z-50 mt-12">
      <div className="container mx-auto py-8">
        <div className="grid grid-cols-1 md:grid-cols-3  gap-8">
          {/* About Us */}
          <div className="ml-4">
            <h5 className="text-lg font-bold mb-4">About Us</h5>
            <p>
              Discover your dream getaway with us! From beachfront villas to
              desert retreats, we offer tailored accommodations for every
              traveler. Explore our curated selection of properties and embark
              on unforgettable journeys worldwide.
            </p>
          </div>

          {/* Contact Us */}
          <div className="ml-4">
            <h5 className="text-lg font-bold mb-4">Contact Us</h5>
            <ul className="space-y-2">
              <li>Email : atithihelpdesk@atithi.com</li>
              <li>Phone : +91 123-456-7890</li>
              <li>
                Address : Cybage Softwares, Cybage Tower Road,Kalyani Nagar,
                Pune, Maharashtra, India
              </li>
            </ul>
          </div>

          {/* Help */}
          <div className="ml-4">
            <h5 className="text-lg font-bold mb-4">Help</h5>
            <ul className="space-y-2">
              <li>
                <Link to="/faq">FAQ</Link>
              </li>
              <li>
                <Link to="/contact">Contact</Link>
              </li>
              <li>
                <Link to="/">Support</Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Social Media Icons and Copyright */}
        <div className="flex flex-col md:flex-row justify-center lg:flex-col items-center mt-8 md:mt-8">
          <ul className="flex space-x-4 md:mr-12">
            <li>
              <Link
                to="https://www.facebook.com/YourWebsite"
                target="_blank"
                rel="noopener noreferrer"
              >
                <i className="fab fa-facebook-square text-3xl"></i>
              </Link>
            </li>
            <li>
              <Link
                to="https://twitter.com/YourWebsite"
                target="_blank"
                rel="noopener noreferrer"
              >
                <i className="fab fa-twitter-square text-3xl"></i>
              </Link>
            </li>
            <li>
              <Link
                to="https://www.instagram.com/YourWebsite"
                target="_blank"
                rel="noopener noreferrer"
              >
                <i className="fab fa-instagram-square text-3xl"></i>
              </Link>
            </li>
          </ul>
          <div className="mt-5">
            <p className="text-center md:text-center">
              &copy; {new Date().getFullYear()} Atithi Company Pvt. Ltd. All
              Rights Reserved.
              <br></br>
              Atithi is part of Booking Holdings Inc., the world leader in
              online travel & related services.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
