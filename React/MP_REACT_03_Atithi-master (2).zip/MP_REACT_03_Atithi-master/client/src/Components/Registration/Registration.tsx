import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

const Register: React.FC = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [role, setRole] = useState<boolean>(false);
  const [nameError, setNameError] = useState<string | null>(null);
  const [emailError, setEmailError] = useState<string | null>(null);
  const [passwordError, setPasswordError] = useState<string | null>(null);
  const [confirmPasswordError, setConfirmPasswordError] = useState<
    string | null
  >(null);
  const [roleError, setRoleError] = useState<string | null>(null);
  const navigate = useNavigate();
  const validateName = (input: string) => {
    const nameRegex = /^[a-zA-Z\s]*$/;
    setNameError(
      !nameRegex.test(input) ? "Name must contain only alphabets" : null
    );
  };

  const validateEmail = (input: string) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    setEmailError(!emailRegex.test(input) ? "Invalid email address" : null);
  };

  const validatePassword = (input: string) => {
    const passwordRegex =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,10}$/;
    setPasswordError(
      !passwordRegex.test(input)
        ? "Password must be between 8 and 10 characters, and contain at least one uppercase letter, one lowercase letter, one number, and one special character"
        : null
    );
  };

  const validateConfirmPassword = (input: string) => {
    setConfirmPasswordError(
      input !== password ? "Passwords do not match" : null
    );
  };

  const validateRole = (input: boolean | undefined) => {
    setRoleError(input === undefined ? "Role is required" : null);
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    validateName(name);
    validateEmail(email);
    validatePassword(password);
    validateConfirmPassword(confirmPassword);
    validateRole(role);

    if (
      nameError ||
      emailError ||
      passwordError ||
      confirmPasswordError ||
      roleError
    ) {
      return;
    }

    if (name && email && password && confirmPassword) {
      try {
        // Example registration logic
        const response = await fetch("http://localhost:3001/user/register", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ name, email, password, role }),
        });

        if (response.ok) {
          toast.success("Registration Successfull");
          navigate("/login");
        } else {
          toast.error("Registration failed.");
        }
      } catch (error) {
        console.error("Error during registration:", error);
      }
    }
  };

  return (
    <div className="w-full max-w-md m-auto mt-20 bg-gray-800 opacity-90 rounded-lg border border-primaryBorder shadow-md py-8 px-4 bg-cover shadow-xl shadow-slate-400">
      <blockquote className="text-2xl font-medium text-center">
        <p className="text-3xl font-sans text-white font-semibold">
          Welcome to
        </p>
      </blockquote>

      <div className="text-primary">
        <div className="flex items-center mt-0 justify-center">
          <Link to="/" className="flex flex-col items-center gap-4">
            <img
              src="../assets/atithi.png"
              alt="Website Logo"
              className="h-18 w-28 md:h-18 md:w-28 justify-center mt-4"
            />
          </Link>
        </div>
        <div className="text-primary m-6">
          <div className="flex items-center justify-center">
            <h1 className="text-3xl font-medium text-primary text-white  mt-0 mb-2">
              Create an Account
            </h1>
          </div>
          <form>
            <label className="text-left text-white ">
              Name<span className="text-red-500 text-xl">*</span> :
            </label>
            <input
              name="name"
              type="text"
              value={name}
              onChange={(e) => {
                setName(e.target.value);
                validateName(e.target.value);
              }}
              placeholder="Name"
              className={` w-full px-3 py-2 border ${
                nameError ? "border-red-500" : "border-gray-300"
              } rounded`}
            />
            {nameError && (
              <p className="text-red-500 text-xs mt-1">{nameError}</p>
            )}
            <label className="text-left text-white ">
              Email<span className="text-red-500 text-xl">*</span> :
            </label>
            <input
              name="email"
              type="email"
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
                validateEmail(e.target.value);
              }}
              placeholder="Email"
              className={`w-full px-3 py-2 border ${
                emailError ? "border-red-500" : "border-gray-300"
              } rounded`}
            />
            {emailError && (
              <p className="text-red-500 text-xs mt-1">{emailError}</p>
            )}
            <label className="text-left text-white ">
              Password<span className="text-red-500 text-xl">*</span> :
            </label>
            <input
              name="password"
              type="password"
              value={password}
              placeholder="Password"
              onChange={(e) => {
                setPassword(e.target.value);
                validatePassword(e.target.value);
              }}
              className={`w-full px-3 py-2 border ${
                passwordError ? "border-red-500" : "border-gray-300"
              } rounded`}
            />
            {passwordError && (
              <p className="text-red-500 text-xs mt-1">{passwordError}</p>
            )}
            <label className="text-left text-white ">
              Confirm Password<span className="text-red-500 text-xl">*</span> :
            </label>
            <input
              name="confirmPassword"
              type="password"
              value={confirmPassword}
              placeholder="Confirm Password"
              onChange={(e) => {
                setConfirmPassword(e.target.value);
                validateConfirmPassword(e.target.value);
              }}
              className={`w-full px-3 py-2 border ${
                confirmPasswordError ? "border-red-500" : "border-gray-300"
              } rounded`}
            />
            {confirmPasswordError && (
              <p className="text-red-500 text-xs mt-1">
                {confirmPasswordError}
              </p>
            )}
            <label className="text-left text-white">Role :</label>
            <select
              name="role"
              value={role ? "admin" : "user"}
              onChange={(e) => {
                const selectedRole = e.target.value === "admin";
                setRole(selectedRole);
                validateRole(selectedRole);
              }}
              className={`w-full px-3 py-2 border ${
                roleError ? "border-red-500" : "border-gray-300"
              } rounded`}
            >
              <option value="user">User</option>
              <option value="admin">Admin</option>
            </select>
            {roleError && (
              <p className="text-red-500 text-xs mt-1">{roleError}</p>
            )}

            <div className="flex items-center mt-3 justify-center">
              <button
                className={
                  "bg-gray-800 hover:bg-slate-600 py-2 px-4 text-md text-white rounded border border-slate focus:outline-none mt-2 focus:border-black"
                }
                onClick={handleRegister}
                value="Register"
              >
                Register
              </button>
              <div className="flex items-center py-2 px-4  justify-center"></div>
            </div>
          </form>

          <div className="flex items-center mt-3 justify-center">
            <Link
              to="/login"
              className={"justify-center text-white hover:underline"}
            >
              Already have an account?{" "}
              <span className="text-red-500">Login</span>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Register;
