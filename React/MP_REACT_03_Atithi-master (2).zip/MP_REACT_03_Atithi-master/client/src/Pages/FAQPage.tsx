import React, { useState } from "react";
import Header from "../Components/Header/Header";
import Footer from "../Components/Footer/Footer";

const FAQPage: React.FC = () => {
  interface FaqItem {
    question: string;
    answer: string;
  }

  const faqData: FaqItem[] = [
    {
      question: "How do I make a reservation?",
      answer:
        "You can make a reservation on our website or contact our customer support.",
    },
    {
      question: "What are the check-in and check-out times?",
      answer: "Check-in time is at 3:00 PM, and check-out time is at 11:00 AM.",
    },
    {
      question: "Is Wi-Fi available in the rooms?",
      answer: "Yes, all rooms are equipped with high-speed Wi-Fi.",
    },
    {
      question: "Do you provide airport shuttle services?",
      answer:
        "We offer airport shuttle services for our guests. Please contact the front desk for arrangements.",
    },
    {
      question: "Are pets allowed?",
      answer:
        "We have a pet-friendly policy. Please inform us in advance if you plan to bring a pet.",
    },
    {
      question: "What amenities are included with the room?",
      answer:
        "Rooms come with complimentary toiletries, coffee maker, and a minibar.",
    },
    {
      question: "Is there parking available for guests?",
      answer: "Yes, we have onsite parking available for our guests.",
    },
    {
      question: "Do you have a cancellation policy?",
      answer:
        "Our cancellation policy allows free cancellation up to 48 hours before check-in. Please check the details when making a reservation.",
    },
    // Add more FAQ items as needed
  ];

  const FaqItem: React.FC<FaqItem> = ({ question, answer }) => {
    const [isOpen, setIsOpen] = useState(false);

    return (
      <div className="bg-white p-4 rounded shadow-md">
        <div
          className="flex items-center justify-between cursor-pointer"
          onClick={() => setIsOpen(!isOpen)}
        >
          <h3 className="text-lg font-semibold">{question}</h3>
          <span
            className={`transform ${
              isOpen ? "rotate-180" : "rotate-0"
            } transition-transform`}
          >
            ▼
          </span>
        </div>

        {isOpen && <p className="mt-4">{answer}</p>}
      </div>
    );
  };

  return (
    <>
      <Header />
      <div className="container mx-auto p-8">
        <h1 className="text-4xl font-bold mb-6 text-gray-800">
          Frequently Asked Questions
        </h1>

        <div className="grid gap-6">
          {faqData.map((item, index) => (
            <FaqItem key={index} {...item} />
          ))}
        </div>
      </div>
      <Footer />
    </>
  );
};

export default FAQPage;
