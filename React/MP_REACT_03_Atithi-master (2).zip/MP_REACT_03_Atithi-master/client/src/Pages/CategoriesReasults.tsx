import React from "react";
import { useLocation, Link } from "react-router-dom";
import { usePlaceContext } from "../Context/PlaceContext";
import Header from "../Components/Header/Header";
import Footer from "../Components/Footer/Footer";
import CategoriesPage from "./CategoriesPage";

const CategoriesResults: React.FC = () => {
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const selectedCategory = searchParams.get("category");

  const { places } = usePlaceContext();

  const filteredPlaces = selectedCategory
    ? places.filter(
        (place) =>
          place?.category?.toLowerCase() === selectedCategory?.toLowerCase()
      )
    : places;

  return (
    <>
      <Header />
      <CategoriesPage />
      <div className="py-16">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-16 mt-16 mb-12 px-12 ">
          {filteredPlaces.map((currentPlace) => (
            <div
              key={currentPlace._id}
              className="border-solid border-2 border-gray-400 rounded-t-lg shadow-lg  overflow-hidden hover:shadow-lg transform transition duration-300"
            >
              <Link to={`/place/${currentPlace._id}`}>
                {currentPlace.photos && currentPlace.photos.length > 0 && (
                  <img
                    src={currentPlace.photos[0]}
                    alt={currentPlace.title}
                    className="h-60 w-full object-cover shadow-lg"
                  />
                )}
                <div className="p-4">
                  <h3 className="text-xl font-semibold mb-2">
                    {currentPlace.title}
                  </h3>
                  <p className="text-gray-700">{}</p>
                  <div className="mt-4 flex justify-between items-center">
                    <span className="text-green-700 font-semibold">
                      ₹ {currentPlace.price} per night
                    </span>
                  </div>
                </div>
              </Link>
            </div>
          ))}
        </div>
      </div>
      <Footer />
    </>
  );
};

export default CategoriesResults;
