import React, { useState, useEffect } from "react";
import AccountNav from "../Components/AccountNav/AccountNav";
import { FaMapMarkerAlt, FaCalendarAlt, FaRupeeSign } from "react-icons/fa";
import { Link } from "react-router-dom";
import Header from "../Components/Header/Header";
import Footer from "../Components/Footer/Footer";

interface Place {
  _id: string;
  photos: string[];
  address: string;
  title: string;
}

interface Bookings {
  _id: string;
  place: Place;
  description: string;
  price: number;
  checkIn: string;
  checkOut: string;
}

const userData: any = localStorage?.getItem("userData");
const user = JSON.parse(userData);

function MyBookingsPage() {
  const token = user.token;
  const [bookings, setBookings] = useState<Bookings[]>([]);

  const getBookings = async () => {
    try {
      const response = await fetch("http://localhost:3001/bookings", {
        method: "GET",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      const result = await response.json();

      setBookings(result.bookings);
    } catch (error) {
      console.log("Error: ", error);
    }
  };

  useEffect(() => {
    getBookings();
  }, []);

  return (
    <>
      <Header />
      <AccountNav />

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 mt-6 p-8">
        {bookings && bookings?.length > 0 ? (
          bookings?.map((element) => (
            <Link to={``} key={element._id}>
              <div className="border-solid border-2 border-gray-400 rounded-t-lg shadow-lg overflow-hidden transform transition duration-300 ">
                <img
                  className="w-full h-48 object-cover"
                  src={element?.place?.photos[0]}
                  alt="Card "
                />
                <div className="p-4">
                  <h3 className="text-xl font-semibold text-gray-800">
                    {element?.place?.title}
                  </h3>
                  <div className="flex items-center mt-2">
                    <FaMapMarkerAlt className="text-gray-600 mr-3" />
                    <span className="text-base text-gray-600">
                      {element?.place?.address}
                    </span>
                  </div>
                  <div className="flex items-center mt-2">
                    <FaCalendarAlt className="text-gray-600 mr-3" />
                    <span className="text-base text-gray-600">
                      {`${new Date(element.checkIn).toLocaleDateString(
                        "en-GB"
                      )} --> ${new Date(element.checkOut).toLocaleDateString(
                        "en-GB"
                      )}`}
                    </span>
                  </div>
                  <div className="flex items-center mt-2">
                    <FaRupeeSign className="text-gray-600 mr-3" />
                    <span className="text-base text-gray-600">
                      {element.price}
                    </span>
                  </div>
                </div>
              </div>
            </Link>
          ))
        ) : (
          <p className=" mx-auto text-2xl font-bold text-gray-800">
            No bookings found.
          </p>
        )}
      </div>
      <Footer />
    </>
  );
}

export default MyBookingsPage;
