import React from "react";
import { Link, useLocation } from "react-router-dom";
import Header from "../Components/Header/Header";
import Footer from "../Components/Footer/Footer";

interface IndexPageProps {
  searchResults: any[]; // Adjust the type as needed
}

const IndexPage: React.FC<IndexPageProps> = () => {
  const location = useLocation();
  const searchResults = location.state?.searchResults || [];
  return (
    <>
      <Header />
      <div className="bg-white py-6 sm:py-8 lg:py-12 align-center flex-center">
        <h1
          style={{
            color: "black",
            fontFamily: "tangerine",
            fontSize: 50,
            fontStyle: "italic",
            textAlign: "center",
          }}
        >
          Search Results
        </h1>
        <div className="mx-auto max-w-screen-2xl px-4 md:px-8 ">
          {searchResults.length === 0 ? (
            <p>No search results found.</p>
          ) : (
            <div className=" grid py-2 px-2 gap-7 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 ">
              {searchResults.map((currentPlace: any) => (
                <div
                  className="border-solid border-2 border-gray-400 rounded-t-lg shadow-lg "
                  key={currentPlace._id}
                >
                  <Link
                    to={`/place/${currentPlace._id}`}
                    key={currentPlace._id}
                    className="group relative  block h-96 overflow-hidden rounded-t-lg bg-gray-100"
                  >
                    {currentPlace.photos && currentPlace.photos.length > 0 && (
                      <img
                        src={currentPlace.photos[0]}
                        loading="lazy"
                        alt={currentPlace.title}
                        className="h-full w-full object-cover  transition duration-200 group-hover:scale-110"
                      />
                    )}
                  </Link>
                  <div className="flex border-black-500 justify-start text-left items-start flex-col shadow-2xl gap-2 rounded-b-lg bg-gray-200 p-4">
                    <div className="text-left items-start">
                      <span className="font-bold text-black-800 transition duration-100 hover:text-gray-500 lg:text-lg">
                        {currentPlace.title}
                      </span>
                      <br />
                      <span className="text-sm text-green-600 ">
                        ₹ {currentPlace.price} per night
                      </span>
                      <br />
                      <span className="text-sm text-gray-600 ">
                        {currentPlace.address}
                      </span>
                      <br />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
      <Footer />
    </>
  );
};

export default IndexPage;
