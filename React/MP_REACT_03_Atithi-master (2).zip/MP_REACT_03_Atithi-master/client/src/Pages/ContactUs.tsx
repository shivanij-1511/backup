import React from "react";
import Footer from "../Components/Footer/Footer";
import Header from "../Components/Header/Header";

const ContactUsPage: React.FC = () => {
  return (
    <>
      <Header />
      <div className="container mx-auto p-8">
        <h1 className="text-4xl font-bold mb-6 text-gray-800">Contact Us</h1>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 p-8 border border-solid border-gray-500 rounded-lg shadow-md">
          <div>
            <h2 className="text-2xl font-semibold mb-4">Send us a Message</h2>
            <form>
              <div className="mb-4">
                <label
                  htmlFor="name"
                  className="block text-sm font-medium text-gray-600"
                >
                  Name
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  className="mt-1 p-2 w-full border rounded-md"
                />
              </div>
              <div className="mb-4">
                <label
                  htmlFor="email"
                  className="block text-sm font-medium text-gray-600"
                >
                  Email
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  className="mt-1 p-2 w-full border rounded-md"
                />
              </div>
              <div className="mb-4">
                <label
                  htmlFor="message"
                  className="block text-sm font-medium text-gray-600"
                >
                  Message
                </label>
                <textarea
                  id="message"
                  name="message"
                  rows={4}
                  className="mt-1 p-2 w-full border rounded-md"
                ></textarea>
              </div>
              <button
                type="button"
                className="bg-gray-800 text-white px-4 py-2 rounded-md hover:bg-gray-600"
              >
                Submit
              </button>
            </form>
          </div>

          <div>
            <h2 className="text-2xl font-semibold mb-4">Visit Us</h2>
            <p className="text-gray-700">123 Main Street</p>
            <p className="text-gray-700">Pune, India</p>

            <h2 className="text-2xl font-semibold my-4">Contact Information</h2>
            <p className="text-gray-700">Email: info@example.com</p>
            <p className="text-gray-700">Phone: +1 (123) 456-7890</p>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default ContactUsPage;
