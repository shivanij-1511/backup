import Axios from "axios";
import AccountNav from "../Components/AccountNav/AccountNav";
import { FaCamera, FaSignOutAlt } from "react-icons/fa";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import Header from "../Components/Header/Header";
import Footer from "../Components/Footer/Footer";

function ProfilePage() {
  const userData: any = localStorage?.getItem("userData");

  const data = JSON.parse(userData);
  const user = data.user;

  const navigate = useNavigate();
  const handleLogout = async () => {
    try {
      const response = await Axios.post("http://localhost:3001/user/logout");
      if (response.status === 200) {
        toast.success(response.data.message);
        localStorage.clear();
        navigate("/");
      } else {
        toast.error("Logout Failed");
      }
    } catch (error) {
      console.error("Error during logout:", error);
    }
  };

  return (
    <>
      <Header />
      <AccountNav />
      <div className="bg-[#071e34] p-6 w-full max-w-md rounded-xl font-sans overflow-hidden mx-auto mt-20 shadow-xl">
        <div className="flex flex-col items-center shadow-lg">
          <div className="w-32 h-32 flex items-center justify-center bg-gray-200 rounded-full mb-4 ">
            <img src={user.picture} alt="" className="rounded-full" />
          </div>
          <Link to={"/edit"}>
            <button className="text-gray-800 border-2 border-gray-600 -translate-y-10 text-2xl bg-white w-10 h-9 px-2 flex items-center justify-center rounded-full cursor-pointer hover:scale-105 transform transition-transform duration-300">
              {/* <MdOutlineCameraAlt /> */}
              <FaCamera />
            </button>
          </Link>
          <div className="text-center">
            <p className="text-4xl text-white font-semibold">{user.name}</p>
            <p className="text-2xl text-gray-200 mt-4">{user.email}</p>
          </div>
        </div>

        <div className="mt-12 mb-4 flex justify-center px-10">
          <button
            className="text-red-700 text-xl bg-white w-28 h-12 p-3 flex items-center justify-center rounded-full cursor-pointer hover:scale-105 transform transition-transform duration-300"
            onClick={handleLogout}
          >
            <FaSignOutAlt className="mr-2" />
            Logout
          </button>
        </div>
      </div>
      <Footer />
    </>
  );
}
export default ProfilePage;
