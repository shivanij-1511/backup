import React, { useEffect, useState } from "react";
import Booking from "../Components/Booking/Booking";
import { useParams } from "react-router-dom";
import axios from "axios";
import Header from "../Components/Header/Header";
import Footer from "../Components/Footer/Footer";

interface Place {
  _id: string;
  photos: string[];
  description: string;
  address: string;
  title: string;
  extraInfo: string;
  perks: any[];
  price: number;
}
function BookingPage() {
  const { id } = useParams();
  const [place, setPlace] = useState<Place | null>(null);

  useEffect(() => {
    const fetchPlaceData = async () => {
      if (!id) {
        return;
      }

      try {
        const response = await axios.get(`http://localhost:3001/places/${id}`);
        setPlace(response.data.place);
      } catch (error) {
        console.error("Error fetching place details:", error);
      }
    };

    fetchPlaceData();
  }, [id]);

  return (
    <>
      <Header />
      {place && (
        <div className="py-6 sm:py-10 lg:py-12 ">
          <div className="mx-auto max-w-screen-2xl px-4 md:px-8 bg-gray-100 rounded ">
            <div className="">
              <h1 className="text-3xl py-2 items-left font-semibold mb-2">
                {place.title}
              </h1>
              <p className="text-gray-500 mb-4">
                Location: <span>{place.address}</span>
              </p>
            </div>
            <div className="mb-4 lg:w-full md:w-auto ">
              {/* Banner Section with 1 large image on the left and 4 images in a grid on the right */}
              <div className="flex flex-col lg:flex-row mb-4 ">
                <img
                  src={place.photos[0]}
                  alt="first"
                  className="w-full lg:w-1/2 mx-2 my-0 lg:mb-0"
                />
                <div className="flex flex-wrap lg:w-1/2 ">
                  <img
                    src={place.photos[1]}
                    alt="second"
                    className="w-1/2 mb-2 px-1 mb-3"
                  />
                  <img
                    src={place.photos[2]}
                    alt="third"
                    className="w-1/2 px-1 mb-3 "
                  />
                  <img
                    src={place.photos[3]}
                    alt="four"
                    className="w-1/2 px-1"
                  />
                  <img
                    src={place.photos[4]}
                    alt="fifth"
                    className="w-1/2 px-1 "
                  />
                </div>
              </div>
            </div>
            <div className="flex lg:flex-nowrap flex-wrap">
              <div className="lg:w-2/3 mx-2">
                {/* Description Section */}
                <div className="mb-4 py-2 px-4 bg-white  rounded-md shadow-md ">
                  <h2 className="text-xl font-semibold mb-2">Description</h2>
                  <p>{place.description}</p>
                </div>
                {/* Perks Section */}
                <div className="mb-4 py-2 px-4 bg-white  rounded-md shadow-md">
                  <h2 className="text-xl font-semibold mb-2">
                    What this place offers
                  </h2>
                  {/* <p>{place.perks}</p> */}
                  <ul className="list-disc pl-4">
                    {place.perks && place.perks.length > 0 ? (
                      place.perks.map((perk, index) => (
                        <li key={index} className="mb-2">
                          {perk}
                        </li>
                      ))
                    ) : (
                      <p>No perks available</p>
                    )}
                  </ul>
                </div>
                <div className="mb-4 py-2 px-4 bg-white  rounded-md shadow-md">
                  <h2 className="text-xl font-semibold mb-2">
                    Terms And Conditions
                  </h2>
                  <p>{place.extraInfo}</p>
                </div>
                <div className="mb-4 py-2 px-4 bg-white  rounded-md shadow-md">
                  <h2 className="text-xl font-semibold mb-2">
                    Price Per Night
                  </h2>
                  <p className="text-xl">Rs {place.price}/-</p>
                </div>
              </div>
              <div className="lg:w-1/3  mb-3 w-full ">
                <Booking />
              </div>
            </div>
          </div>
        </div>
      )}
      <Footer />
    </>
  );
}

export default BookingPage;
