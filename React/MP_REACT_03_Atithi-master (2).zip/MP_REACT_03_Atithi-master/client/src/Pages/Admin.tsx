import React, { useState } from "react";
import Sidebar from "../Components/Admin/Sidebar";
import Bookings from "../Components/Admin/Bookings";
import Places from "../Components/Admin/Places";
import Users from "../Components/Admin/Users";
import Header from "../Components/Header/Header";

const AdminPage: React.FC = () => {
  const [selectedTab, setSelectedTab] = useState<string>("bookings");
  const [sidebarOpen, setSidebarOpen] = useState<boolean>(false);

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  const renderTabContent = () => {
    switch (selectedTab) {
      case "bookings":
        return <Bookings />;
      case "places":
        return <Places />;
      case "users":
        return <Users />;
      default:
        return null;
    }
  };

  return (
    <>
      <Header />
      <div className="flex h-screen bg-gray-200">
        {/* Hamburger Button */}
        <button
          onClick={toggleSidebar}
          className=" fixed top-5 left-6 px-2 py-2 w-20 text-white font-bold focus:outline-none z-40"
        >
          {sidebarOpen ? "✖" : "☰"}
        </button>

        {/* Sidebar */}
        {sidebarOpen && <Sidebar onSelectTab={setSelectedTab} />}

        {/* Main Content */}
        <div
          className={`flex-1 overflow-hidden bg-gray-100  ${
            sidebarOpen ? "ml-50" : ""
          }`}
        >
          <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-200">
            {renderTabContent()}
          </main>
        </div>
      </div>
    </>
  );
};

export default AdminPage;
