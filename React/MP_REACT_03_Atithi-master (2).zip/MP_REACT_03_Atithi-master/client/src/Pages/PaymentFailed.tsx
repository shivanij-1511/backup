import React from "react";
import { useNavigate } from "react-router-dom";

const PaymentFailed: React.FC = () => {
  const navigate = useNavigate();
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <div className="bg-white p-8 rounded-md shadow-md max-w-md w-full">
        <h2 className="text-3xl font-semibold text-red-600 mb-4">
          Payment Failed
        </h2>
        <p className="text-gray-600 mb-6">
          Unfortunately, the payment process failed. Please try again.
        </p>
        <button
          className="bg-gray-800 text-white py-2 px-4 rounded-md hover:bg-gray-600"
          onClick={() => navigate("/")}
        >
          Retry Booking
        </button>
      </div>
    </div>
  );
};

export default PaymentFailed;
