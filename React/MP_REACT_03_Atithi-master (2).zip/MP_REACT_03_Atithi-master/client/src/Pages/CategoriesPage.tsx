import React, { useEffect, useState } from "react";
import { MdForest, MdCastle } from "react-icons/md";
import { GiIsland } from "react-icons/gi";
import { FaRegSnowflake } from "react-icons/fa";
import { HiHomeModern } from "react-icons/hi2";
import { RiCactusFill } from "react-icons/ri";
import { LuTent } from "react-icons/lu";
import { useNavigate } from "react-router-dom";

const CategoriesPage: React.FC = () => {
  const navigate = useNavigate();
  const [selectedCategory, setSelectedCategory] = useState<string>("");

  useEffect(() => {}, [selectedCategory]);

  const handleCategorySelect = (category: string) => {
    setSelectedCategory(category);
    navigate(`/category?category=${category}`);
  };

  return (
    <div className="py-3 w-full bg-white fixed top-18 z-10  ">
      <div
        className="shadow-lg px-4 my-auto mt-6 w-full md:w-3/4 lg:w-2/3 xl:w-1/2 sm:w-fit bg-white flex flex-wrap justify-around gap-4 sm:gap-8 py-2  sm:rounded-2xl sm:border-transparent sm:text-sm sm:px-6 sm:mt-8  "
        style={{
          border: "2px solid gray",
          margin: "0 auto",
        }}
      >
        <button
          className={`flex flex-col text-lg items-center ${
            selectedCategory === "palace" ? "text-gray-300" : "text-black"
          }`}
          onClick={() => handleCategorySelect("palace")}
        >
          <MdCastle className="text-3xl" />
          Palace
        </button>
        <button
          className={`flex flex-col text-lg items-center ${
            selectedCategory === "Hut" ? "text-gray-300" : "text-black"
          }`}
          onClick={() => handleCategorySelect("Hut")}
        >
          <MdForest className="text-3xl" />
          Hut
        </button>
        <button
          className={`flex flex-col text-lg items-center ${
            selectedCategory === "Beach" ? "text-gray-300" : "text-black"
          }`}
          onClick={() => handleCategorySelect("Beach")}
        >
          <GiIsland className="text-3xl" />
          Beach
        </button>
        <button
          className={`flex flex-col text-lg items-center ${
            selectedCategory === "Villa" ? "text-gray-300" : "text-black"
          }`}
          onClick={() => handleCategorySelect("Villa")}
        >
          <FaRegSnowflake className="text-3xl" />
          Villa
        </button>
        <button
          className={`flex flex-col text-lg items-center ${
            selectedCategory === "Desert" ? "text-gray-300" : "text-black"
          }`}
          onClick={() => handleCategorySelect("Desert")}
        >
          <RiCactusFill className="text-3xl" />
          Desert
        </button>
        <button
          className={`flex flex-col text-lg items-center ${
            selectedCategory === "Mansion" ? "text-gray-300" : "text-black"
          }`}
          onClick={() => handleCategorySelect("Mansion")}
        >
          <HiHomeModern className="text-3xl" />
          Mansion
        </button>
        <button
          className={`flex flex-col text-lg items-center ${
            selectedCategory === "Camp" ? "text-gray-300" : "text-black"
          }`}
          onClick={() => handleCategorySelect("Camp")}
        >
          <LuTent className="text-3xl" />
          Camp
        </button>
      </div>
    </div>
  );
};

export default CategoriesPage;
