import React, { useEffect, useState } from "react";
import AccountNav from "../Components/AccountNav/AccountNav";
import { FaPlus } from "react-icons/fa";
import { Link } from "react-router-dom";
import { usePlaceContext } from "../Context/PlaceContext";
import Header from "../Components/Header/Header";
import Footer from "../Components/Footer/Footer";

interface Place {
  _id: string;
  photos?: string[] | any;
  address: string;
  title: string;
  price: number;
  category: string;
  owner: string;
}

function MyAccomodations() {
  const { places } = usePlaceContext();
  const [bookings, setBookings] = useState<Place[]>([]);

  useEffect(() => {
    const userDataString = localStorage.getItem("userData");
    if (!userDataString) {
      // Handle the case when userData is not available in local storage
      return;
    }

    const userData = JSON.parse(userDataString);
    const userId = userData.user._id;

    const filteredBookings = places.filter((place) => place.owner === userId);
    setBookings(filteredBookings);
  }, [places]);

  const handleRemovePlace = (id: string) => {
    const updatedBookings = bookings.filter((booking) => booking._id !== id);
    setBookings(updatedBookings);
    // Here you can implement the logic to remove the place from the database or perform any other necessary actions
  };

  return (
    <>
      <Header />
      <AccountNav />
      <div className="flex justify-center mt-8 hover:scale-105 transform transition-transform duration-300">
        <Link to="/account/places/new">
          <button className="bg-gray-800 text-white w-40 h-12 p-3 flex items-center justify-center rounded-full cursor-pointer">
            <FaPlus className="mr-3" />
            Add Place
          </button>
        </Link>
      </div>

      <div className="p-8 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 mt-6">
        {bookings && bookings?.length > 0 ? (
          bookings?.map((element) => (
            <Link to={``} key={element._id}>
              <div className="border-solid border-2 border-gray-400 rounded-t-lg shadow-lg overflow-hidden ">
                <img
                  className="w-full h-48 object-cover"
                  src={element?.photos[0]}
                  alt="Card "
                />
                <div className="p-4">
                  <h3 className="text-xl font-semibold text-gray-800">
                    {element?.title}
                  </h3>
                  <div className="flex items-center mt-2">
                    <span className="text-base text-gray-600">
                      {element?.address}
                    </span>
                  </div>
                  <button
                    className="mt-4 p-2 text-md  text-center bg-gray-900 text-white hover:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-gray-500 rounded-lg"
                    onClick={() => handleRemovePlace(element._id)}
                  >
                    Remove Place
                  </button>
                </div>
              </div>
            </Link>
          ))
        ) : (
          <p className=" mx-auto text-2xl font-bold text-gray-800">
            No Property Listed.
          </p>
        )}
      </div>
      <Footer />
    </>
  );
}

export default MyAccomodations;
