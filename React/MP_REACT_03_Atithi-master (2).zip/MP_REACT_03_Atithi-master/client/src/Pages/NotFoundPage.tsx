import React from "react";
import { useNavigate } from "react-router-dom";

const NotFound = () => {
  const navigate = useNavigate();
  return (
    <div className="flex items-center justify-center h-screen">
      <div className="text-center">
        <h1 className="text-4xl font-bold mb-4">404 - Not Found</h1>
        <p className="text-gray-600">
          Sorry, the page you are looking for does not exist.
        </p>
        <button
          className="bg-gray-800 text-white py-2 px-4 rounded-md hover:bg-gray-600 mt-5"
          onClick={() => navigate("/")}
        >
          Go To HomePage
        </button>
      </div>
    </div>
  );
};

export default NotFound;
