export interface Product{
    id?:number,
    productName:string,
    brandName:string,
    price:number,
    quantity:number
}