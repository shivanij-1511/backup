export interface Shop{
    id:number,
    shopName:string,
    shopCategory:string,
    address:string,
    isShopOpen:boolean
}