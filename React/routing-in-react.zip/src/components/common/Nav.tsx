import React from 'react';
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import ProductDetails from '../product/ProductDetails';
import AddProduct from '../product/AddProduct';
import EditProduct from '../product/EditProduct';
import DeleteProduct from '../product/DeleteProduct';
import Demo from '../product/Demo';
import CustomerDetails from '../customer/CustomerDetails';
import ShopDetails from '../shops/ShopDetails';
import AddCustomer from '../customer/AddCustomer';

function Nav() {
  return (
    <div>
      <BrowserRouter>
        <div className='navbar'>
          <Link to={'product/add'}>Add Product</Link>
          <Link to={'customer/add'}>Add Customer</Link>
          <Link to={'product/edit'}>Edit Product</Link>
          <Link to={'product/delete'}>Delete Product</Link>
          <Link to={'/demo'}>Check</Link>
          <Link to={'/customerdetails'}>Customer Details</Link>
          <Link to={'/shops'}>Shop Details</Link>
          
          <Link to={'/'}>Product Details</Link>
        </div>
        <Routes>
          <Route path='/' Component={ProductDetails}></Route>
          <Route path='product'>
            <Route path='add' Component={AddProduct}></Route>
            <Route path='edit/:pid' Component={EditProduct}></Route>
            <Route path='delete/:pid' Component={DeleteProduct}></Route>
          </Route>
          <Route path='/demo' Component={Demo}></Route>
          <Route path='/customerdetails' Component={CustomerDetails}></Route>
          <Route path='customer'>
            <Route path='add' Component={AddCustomer}></Route>
          </Route>

          <Route path='/shops' Component={ShopDetails}></Route>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default Nav;
