import React, { useEffect, useState } from 'react';
import { Shop } from '../../model/Shop';
import { ShopService } from '../../service/ShopService';

const ShopDetails: React.FC = () => {
  const [shops, setShops] = useState<Shop[]>([]);

  useEffect(() => {
    ShopService.getShopDetails()
      .then((response) => {
        console.log("response in Component: ", response);
        setShops(response);
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);

  return (
    <div>
      <h1>Shop details</h1>
      <table align="center" border={1} className='table table-striped table bordered'>
        <thead>
          <tr>
            <th>Shop No.</th>
            <th>Shop Name</th>
            <th>Shop Category</th>
            <th>Address</th>
            <th>Open or Close</th>
          </tr>
        </thead>
        <tbody>
          {shops.map((shop) => (
            <tr key={shop.id}>
              <td>{shop.id}</td>
              <td>{shop.shopName}</td>
              <td>{shop.shopCategory}</td>
              <td>{shop.address}</td>
              <td>{shop.isShopOpen ? "Open" : "Closed"}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ShopDetails;
