import React, { useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { CustomerService } from '../../service/CustomerService';

function DeleteCustomer() {
    const navigate = useNavigate();
    const params = useParams<{ cid: string }>();
    const customerId = params.cid;

    useEffect(() => {
        if (customerId) {
            CustomerService.deleteCustomer(customerId)
                .then(() => {
                    navigate('/');
                })
                .catch((error: any) => {
                    console.log(error);
                });
        }
    }, [customerId, navigate]);

    return (
        <div>
            {/* Placeholder content can be added here if needed */}
        </div>
    );
}

export default DeleteCustomer;
