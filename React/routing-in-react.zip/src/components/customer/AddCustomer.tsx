import React from 'react';
import { useForm } from 'react-hook-form';
import { Customer } from '../../model/Customer';

function AddCustomer() {
    // useForm hook
    const { register, handleSubmit } = useForm<Customer>({
        defaultValues: {
            name: "",
            address: "",
            email: ""
           
        }
    });

    let addCustomerDetails = (data: Customer) => {
        console.log("Submitted Data:", data);
        
    };

    return (
        <div>
            <form onSubmit={handleSubmit(addCustomerDetails)}>
                <table>
                    <tbody>
                        <tr>
                            <td> Name</td>
                            <td><input type='text' {...register("name")} /></td>
                        </tr>
                        <tr>
                            <td>Address</td>
                            <td><input type='text' {...register("address")} /></td>
                        </tr>
                        <tr>
                            <td>Email</td>
                            <td><input type='email' {...register("email")} /></td>
                        </tr>
                       
                        <tr>
                            <td></td>
                            <td><input type='submit' value={"Add Customer"} /></td>
                        </tr>
                    </tbody>
                </table>
            </form>
        </div>
    );
}

export default AddCustomer;
