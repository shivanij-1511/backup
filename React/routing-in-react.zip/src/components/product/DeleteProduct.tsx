import React, { useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ProductService } from '../../service/ProductService';

function DeleteProduct() {
    const navigate = useNavigate();
    const params = useParams<{ pid: string }>();
    const productId = params.pid;

    useEffect(() => {
        if (productId) {
            ProductService.deleteProduct(productId)
                .then((response: any) => {
                    navigate('/');
                })
                .catch((error: any) => {
                    console.log(error);
                });
        }
    }, [productId, navigate]);

    return (
        <div>
            {/* Placeholder content can be added here if needed */}
        </div>
    );
}

export default DeleteProduct;
