import React, { useEffect, useState } from 'react';
import { ProductService } from '../../service/ProductService';
import { Product } from '../../model/Product';
import { Link } from 'react-router-dom';

const ProductDetails: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);

  useEffect(() => {
    console.log("Component Mounted");
    ProductService.getProductDetails()
      .then((response) => {
        console.log("response in Component:", response);
        setProducts(response);
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);

  return (
    <div>
      <h1>Product Details</h1>
      <table align="center" border={1} className="table table-striped table-bordered">
        <thead>
          <tr>
            <th>ID</th>
            <th>Product Name</th>
            <th>Brand Name</th>
            <th>Quantity</th>
            <th>Price</th>
          </tr>
        </thead>
        <tbody>
          {products.map((product) => (
            <tr key={product.id}>
              <td>{product.id}</td>
              <td>{product.productName}</td>
              <td>{product.brandName}</td>
              <td>{product.quantity}</td>
              <td>{product.price}</td>
              <td><Link to={`/product/delete/${product.id}`}>Delete</Link></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default ProductDetails;
