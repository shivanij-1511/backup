import React from 'react'
import { useForm } from 'react-hook-form'
import { Product } from '../../model/Product';
 
function AddProduct() {
  //useForm hook
  const {register,handleSubmit}=useForm<Product>({
    defaultValues:{
      productName:"AC",
      brandName:"TATA",
      price:40000
    }
  });
  // const {name,onBlur,onChange,ref}=register("productName");
  // const {}=register("brandName");
  // const {}=register("price");
  let addProductDetails=(data:Product)=>{
      console.log("Submited Data:"+data);
      //Call service hit api
     
  }
  return (
    <div>
      <form onSubmit={handleSubmit(addProductDetails)}>
        <table>
          <tbody>
            <tr>
              <td>Product Name</td>
              <td><input type='text' {...register("productName")}></input></td>
              {/* <td><input type='text'
                  name={name}
                  onChange={onChange}
                  onBlur={onBlur}
                  ref={ref}
              ></input></td> */}
            </tr>
            <tr>
              <td>Brand Name</td>
              <td><input type='text' {...register("brandName")}></input></td>
            </tr>
            <tr>
              <td>Price</td>
              <td><input type='number' {...register("price")}></input></td>
            </tr>
            <tr>
              <td></td>
              <td><input type='submit' value={"Add Product"}></input></td>
            </tr>
          </tbody>
        </table>
      </form>
    </div>
  )
}
 
export default AddProduct
 