//Sync Execution
// console.log("Start Execution!!!");
 
 
// function show(name)
// {
//     console.log("In show Function");
//     return name;
// }
// result=show("Sonali");
// console.log("Result:"+result);
// console.log("End Execution!!!");
 
 
 
//Promise--
/*
 Promise constructor --callback function as parameter
 callback function takes --reject and resolve as parameter
 resolve and reject are 2 predefined functions
 on success --resolve--with success msg
 on failure---reject--with error msg
 
 resolve---then
 reject----catch
*/
// let promise=new Promise((resolve,reject)=>{
//     let status=false;
//     if(status)
//     {
//         resolve("Execution Successful")//then
//     }
//     else{
//         reject("Execution Failed")
//     }
// })
 
// promise.then((response)=>{console.log(response);})
// .catch((error)=>{console.log(error);})
 
//Async
console.log("Start Execution!!!");
 
// function show(name)
// {
//     console.log("In show Function");
 
//     //code which will take 3000 ms-- to complete execution
//     setTimeout(()=>{
//         console.log("In Callback");
//         return name;
//     },3000)    
// }
 
//Get API
function show(name)
{
    console.log("In show Function");
    //Promise
    let promise=new Promise((resolve,reject)=>{
        //code which will take 3000 ms-- to complete execution
        setTimeout(()=>{
            console.log("In SetTimeOut");
           resolve("Name:"+name)
        },3000)  
    })    
    return promise;
}
//Service
// show("Sonali").then((msg)=>{
//     console.log(msg);
//     console.log("End Execution!!!");
// })
 
 
//Consumer--service
async function getName(name)
{
        let result=await show(name)//API call
        console.log(result);
        console.log("Execution End!!!");
}
 
getName("Sonali Ashish Maind");