import React from 'react'

function EditProduct() {
  return (
    <div>
      <h1>Edit Product</h1>
    </div>
  )
}

export default EditProduct
