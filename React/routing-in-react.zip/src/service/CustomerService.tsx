import axios from "axios";
import { Customer } from "../model/Customer";

export class CustomerService {
    static url: string = "http://localhost:3000/Customers";

    static async getCustomerDetails(): Promise<Customer[]> {
        let response = await axios.get(this.url);
        console.log(response);
        return response.data as Customer[];
    }

    static async deleteCustomer(customerId: string): Promise<void> {
        await axios.delete(`${this.url}/${customerId}`);
    }
}
