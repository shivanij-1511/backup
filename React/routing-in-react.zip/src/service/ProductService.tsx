import axios from "axios";
import { Product } from "../model/Product";

export class ProductService {
    // Static method to perform CRUD operation to hit ---API
    static url: string = "http://localhost:3000/Products";

    static async getProductDetails(): Promise<Product[]> {
        // GET API --axios
        let response = await axios.get(this.url);
        console.log(response);
        return response.data as Product[];
    }

    static async deleteProduct(productId: string): Promise<void> {
        await axios.delete(`${this.url}/${productId}`);
    }
}
