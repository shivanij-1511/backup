// import axios from "axios";
// import { Product } from "../model/Product";

// export class ProductService{

//     // static method to perform CRUD operation to hit ---API
//     static url:string="http://localhost:3000/Products";

//     static async getProductDetails():Promise<Product[]>
//     {
//         // GET API --axios
//         let response = await axios.get(this.url);
//         console.log(response);
//         return response.data as Product[];
//     }

// }

import axios from "axios";
import { Shop } from "../model/Shop";

export class ShopService{
    static url:string="  http://localhost:3000/Shops";

    static async getShopDetails():Promise<Shop[]>
    {
        let response = await axios.get(this.url);
        console.log(response);
        return response.data as Shop[]
        

    }
}