import React from 'react';
import logo from './logo.svg';
import './App.css';
import Nav from './components/common/Nav';

function App() {
  return (
    <div className="App">
     <Nav></Nav>
    </div>
  );
}

export default App;
