import React from 'react';
import logo from './logo.svg';
import './App.css';
import Nav from './components/common/Nav';
 
function App() {
  return (
    <div className="App">
      <Nav></Nav>
     {/* <ProductDetails name={"Laptop"} quantity={100}></ProductDetails>
     <hr></hr>
     <AddProduct></AddProduct>
     <hr></hr>
     <AddEmployee></AddEmployee>
     <hr></hr>
     <AddCustomer></AddCustomer> */}
    </div>
  );
}
 
export default App;
 