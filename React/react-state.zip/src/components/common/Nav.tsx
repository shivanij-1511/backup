import React from 'react'
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom'
import EmployeeDetails from '../Employee/EmployeeDetails'
import AddEmployee from '../Employee/AddEmployee'
import AddProduct from '../Product/AddProduct'

function Nav() {
  return (
    <div>
      <BrowserRouter>
        <div className='navbar'>
            <Link to={'employee/add'}>Add Employee</Link>
            <Link to={'employee/add'}>Add Product</Link>

        </div>

        <Routes>
            <Route path='/' Component={EmployeeDetails}></Route>
            <Route path='employee/add' Component={AddEmployee} ></Route>
            <Route path='product/add' Component={AddProduct} ></Route>
        </Routes>
      </BrowserRouter>
    </div>
  )
}

export default Nav
