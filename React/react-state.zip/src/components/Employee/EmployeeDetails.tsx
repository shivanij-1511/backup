import React from 'react'

function EmployeeDetails() {
  return (
    <div>
      <h1>EMPLOYEE DETAILS</h1>
    </div>
  )
}

export default EmployeeDetails
