import React, { useState } from 'react'
type prop_type={
    name:string,
    quantity:number
}
function ProductDetails(props:prop_type) {
    // props.name="AC";//Error--Immutable--read only
    //state
    const [count,setCount]=useState(props.quantity)
 
    //Handler Mathod
    let incrementCount=()=>{setCount(count+2)}
    let decrementCount=()=>{setCount(count-2)}
  return (
    <div>
        {props.quantity}<br></br>
      {props.name}
      <hr></hr>
      State Example
      <hr></hr>
      {count}<br></br>
      <button onClick={incrementCount}>Increment</button><br></br>
      <button onClick={()=>{setCount(count-2)}}>Decrement</button>
    </div>
  )
}
 
export default ProductDetails